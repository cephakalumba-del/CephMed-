# Mettre CephMed sur GitHub et protéger votre espace propriétaire

## 1. Ce qui a changé dans les quiz

- **20 secondes par question**, toujours dans l’ordre.
- Un clic enregistre la réponse de façon définitive et ouvre immédiatement la question suivante.
- À l’expiration des 20 secondes, une absence de réponse vaut zéro point et la question suivante prend le relais.
- Aucun retour ni reprise d’une question passée. Un rechargement, un second onglet ou une coupure réseau ne remet pas le compteur à zéro.
- Le serveur PostgreSQL mesure les délais et le serveur applicatif corrige automatiquement. Le navigateur n’envoie ni temps officiel, ni score.
- Le serveur ne transmet qu’une question à la fois, jamais les questions futures ou les corrections.
- Le classement trie **d’abord par nombre de bonnes réponses décroissant**, puis **par temps cumulé sur les bonnes réponses croissant**. Exemple : 4/5 en 15 secondes passe devant 4/5 en 23 secondes. Un 5/5 reste devant un 4/5. Les temps sont enregistrés en millisecondes ; les égalités exactes sont ex æquo.
- Les temps de réception et de traitement serveur, réseau inclus, font partie du délai. Le compteur affiché est une estimation synchronisée ; seule l’horloge du serveur fait foi.
- Une session sans navigateur est finalisée automatiquement à partir de ses échéances à la prochaine consultation serveur, notamment lorsque vous ouvrez ou actualisez les rapports. Aucun processus permanent n’est nécessaire.
- Les participations commencées bloquent la modification des questions. Les archives antérieures au chronomètre restent conservées, sans temps inventé, et ne participent pas au nouveau classement. Les comptes de démonstration sont également hors classement officiel.

### Qui voit quoi ?

**Vous seul** voyez immédiatement la correction automatique, les réponses choisies, les bonnes réponses, les explications, le temps de chaque réponse et les questions expirées. Dans votre studio, ouvrez **Classement & corrections**, sélectionnez éventuellement un quiz puis **Voir le détail**.

Le participant voit uniquement la confirmation d’enregistrement. **Aucun résultat n’est publié automatiquement.** Si vous cliquez sur **Publier le classement**, seuls les noms, les scores et les temps de départage du classement officiel deviennent publics. Les corrections détaillées restent privées, même après cette publication. La publication est définitive et refuse de couper une participation encore en cours.

## 2. Accéder à votre studio — vous uniquement

Il n’y a plus de lien d’administration dans le pied de page ni de formulaire public de configuration. Le lien **Mon studio** apparaît dans le menu de compte **uniquement après votre connexion propriétaire**. Une autre personne visitant `/studio` voit la page introuvable. Les lectures privées et toutes les actions d’administration refont le contrôle côté serveur : cacher le lien est une mesure de discrétion, pas la protection principale.

### Configuration requise, dans les secrets de l’hébergement

- `GOOGLE_CLIENT_ID` : client OAuth Google de type application Web.
- `GOOGLE_CLIENT_SECRET` : secret du client OAuth, jamais dans GitHub.
- `OWNER_EMAIL` : **votre adresse Google exacte**. Sans cette variable, personne n’est propriétaire. Elle n’est pas un mot de passe et n’est pas modifiable depuis le site.
- `APP_URL` : URL canonique HTTPS de votre site, sans slash final.
- `DATABASE_URL` : connexion PostgreSQL privée.
- `ALLOW_DEMO_LOGIN=false` pour une ouverture publique.
- `OWNER_GOOGLE_SUB` : optionnel, verrouillage explicite sur l’identifiant immuable de votre compte Google.

La première connexion Google **vérifiée** correspondant à `OWNER_EMAIL` lie automatiquement cet e-mail à votre identifiant Google immuable (`sub`) dans PostgreSQL. Un autre identifiant ne peut pas remplacer ce lien. Les comptes de démonstration ne peuvent jamais devenir propriétaires. Si vous avez déjà renseigné `OWNER_GOOGLE_SUB`, il est vérifié explicitement. Les anciennes sessions ne gagnent pas des droits d’administration : reconnectez-vous après la configuration.

Les sessions propriétaire expirent après **8 heures**, les sessions lecteurs après 14 jours. Les jetons sont aléatoires, stockés sous forme d’empreintes SHA-256 ; les cookies sont HTTP-only, Secure en production et SameSite=Lax. Google est validé avec signature JWT, issuer, audience, nonce et PKCE. Les requêtes du quiz vérifient aussi leur origine. Le studio interdit la mise en cache, l’indexation et l’intégration dans une frame. Dans une prévisualisation intégrée, ouvrez le site dans un **nouvel onglet** pour accéder au studio.

### Dans Google Cloud

1. Configurez l’écran de consentement pour CephMed.
2. Créez un client OAuth de type **Application Web**.
3. Ajoutez votre domaine dans les origines autorisées.
4. Ajoutez exactement l’URI `https://votre-domaine.fr/api/auth/callback/google` dans les URI de redirection autorisées. Remplacez le domaine par celui de `APP_URL`.
5. Si l’application Google est encore en test, ajoutez votre compte aux utilisateurs de test. Publiez l’écran de consentement avant d’ouvrir les connexions à tous.
6. Renseignez les variables côté hébergeur, redéployez puis connectez-vous avec votre compte Google. Ouvrez le menu portant votre prénom : **Mon studio** doit apparaître.

**Activez la validation en deux étapes, idéalement une clé de sécurité ou une passkey, sur votre compte Google et sur GitHub.** CephMed n’ajoute pas un second facteur indépendant et ne peut pas vérifier que vous avez activé celui de Google. Aucun site ne peut garantir une sécurité absolue ; la sécurité de vos comptes, de votre hébergeur et de votre base reste essentielle.

### Si le studio reste masqué

Vérifiez l’adresse `OWNER_EMAIL`, le compte Google réellement utilisé, les secrets OAuth et l’URL de redirection. Déconnectez-vous puis reconnectez-vous : une session lecteur existante ne suffit pas. Un administrateur de l’hébergement peut retrouver votre `google_id` dans la table `users`, après votre authentification Google, puis renseigner `OWNER_GOOGLE_SUB` dans les secrets. Ne divulguez pas votre identité technique ou vos jetons dans un dépôt public.

Ne créez jamais de bouton « devenir administrateur », de mot de passe par défaut ou de lien secret qui contourne ces contrôles. Le premier inscrit n’obtient aucun privilège.

## 3. La méthode simple : GitHub Desktop

1. **Téléchargez ou exportez le projet CephMed** depuis votre environnement de création, puis décompressez-le dans un dossier local. Vous devez voir `package.json`, `src/`, `public/` et `.gitignore`.
2. Installez Git et [GitHub Desktop](https://desktop.github.com/), puis connectez-vous à votre compte GitHub.
3. Si le dossier n’est pas encore un dépôt Git, ouvrez un terminal dans ce dossier et exécutez `git init -b main`. Cette commande reste locale et ne publie rien.
4. Dans GitHub Desktop, choisissez **File → Add local repository**, puis sélectionnez ce dossier.
5. Dans **Changes**, examinez la liste des fichiers. **Les fichiers `.env`, les clés, les exports de données et `artifacts/` ne doivent pas apparaître.** Le fichier `.env.example`, vide de secrets réels, peut être partagé. Ce projet fournit déjà un `.gitignore` adapté.
6. Saisissez un message tel que « Première version de CephMed », puis cliquez sur **Commit to main**.
7. Cliquez sur **Publish repository**, nommez le dépôt `cephmed` et **conservez l’option de dépôt privé** (*Keep this code private*), recommandée pour démarrer.
8. Cliquez sur **Publish repository**, puis **View on GitHub** pour vérifier vos fichiers.

Pour les modifications suivantes : contrôlez la liste, **Commit to main**, puis **Push origin**. N’ajoutez aucun collaborateur auquel vous ne souhaitez pas donner accès au code.

## 4. Variante avec les commandes Git

Créez d’abord sur GitHub un dépôt **privé et vide**, appelé `cephmed`, sans README, licence ni gitignore initiaux : ils sont déjà dans votre projet.

Dans le dossier du projet :

```bash
git init -b main
git check-ignore .env .env.local node_modules .next artifacts
git status --short --untracked-files=all
```

La commande `git check-ignore` doit confirmer que vos fichiers secrets existants sont ignorés. Avant l’ajout, inspectez également les fichiers sources et le README pour vous assurer qu’aucun secret n’y a été copié.

```bash
git add .
git diff --cached --name-only
git diff --cached
```

**Vérifiez cette liste et ce diff avant de continuer.** Ni `.env`, ni jeton OAuth, ni mot de passe, ni clé privée, ni export de participants ne doivent être présents.

```bash
git commit -m "CephMed : quiz chronometres et studio prive"
git remote add origin https://github.com/VOTRE-COMPTE/cephmed.git
git push -u origin main
```

Remplacez `VOTRE-COMPTE` par votre identifiant GitHub. Authentifiez-vous avec GitHub Desktop, le gestionnaire d’identifiants de Git ou SSH. N’insérez jamais un jeton dans l’URL du dépôt. Si un dépôt ou un remote existe déjà, inspectez `git status` et `git remote -v` au lieu de les recréer. Ne faites pas de push forcé pour contourner une erreur.

### Si un secret a déjà été commité

Ajouter un `.gitignore` ne retire pas un secret de l’historique. **Révoquez ou remplacez immédiatement le secret exposé**, puis suivez la procédure officielle GitHub de suppression des données sensibles de l’historique. Une suppression du fichier dans le dernier commit ne suffit pas. Faites cette opération avec précaution, surtout si d’autres personnes ont cloné le dépôt.

Documentation officielle :
- [Ajouter un projet local à GitHub](https://docs.github.com/en/migrations/importing-source-code/using-the-command-line-to-import-source-code/adding-locally-hosted-code-to-github)
- [Supprimer des données sensibles d’un dépôt](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/removing-sensitive-data-from-a-repository)

## 5. GitHub n’est pas l’hébergement du site

GitHub sauvegarde le code. **GitHub Pages ne peut pas faire fonctionner cette application** : CephMed nécessite un serveur Next.js, des routes protégées, des Server Actions et PostgreSQL.

Pour le mettre en ligne :

1. Choisissez un hébergement compatible **Next.js App Router / Node.js** (par exemple Vercel avec PostgreSQL géré, ou un serveur Node avec PostgreSQL).
2. Reliez votre dépôt privé depuis l’interface de l’hébergeur.
3. Créez une base PostgreSQL de production ; ajoutez `DATABASE_URL` et les variables Google/propriétaire aux **variables d’environnement sécurisées de l’hébergeur**, pas au dépôt.
4. Installez les dépendances avec `npm ci`. Exécutez `npx drizzle-kit push` contre la base de production après sauvegarde et revue des changements. Pour des évolutions fréquentes en production, préférez des migrations versionnées, relues et déployées de manière contrôlée.
5. Vérifiez `npx next typegen`, `npm exec tsc -- --noEmit --pretty false`, puis `npm run build`. L’hébergement doit lancer le serveur Next.js avec le port qu’il fournit.
6. Configurez le domaine HTTPS et actualisez `APP_URL` ainsi que la redirection OAuth Google pour ce domaine.
7. Vérifiez `/api/health`, la connexion Google, un quiz complet, un compte lecteur sans accès à `/studio`, et votre propre accès propriétaire.
8. Activez les sauvegardes de la base, la double authentification de vos comptes, les alertes de sécurité des dépendances et la restriction d’accès aux secrets.

**Le dépôt ne contient pas votre base de données.** Les publications créées dans le studio, les commentaires, les comptes et les résultats résident dans PostgreSQL. Leur transfert demande une sauvegarde/restauration privée, jamais un export public dans GitHub.

Avant l’ouverture publique, complétez aussi vos mentions légales et les coordonnées de contact. Le formulaire de newsletter enregistre des inscriptions mais aucun prestataire d’envoi automatique n’est encore configuré.
