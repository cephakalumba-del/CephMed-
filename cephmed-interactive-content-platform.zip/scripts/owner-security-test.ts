import "dotenv/config";
import assert from "node:assert/strict";
import { createHash, randomBytes, randomUUID } from "node:crypto";
import { spawn, type ChildProcess } from "node:child_process";
import { createServer } from "node:net";
import { mkdir } from "node:fs/promises";
import { chromium, expect, type BrowserContext, type Request } from "@playwright/test";
import { and, eq, inArray } from "drizzle-orm";
import { db, pool } from "@/db";
import { publications, quizAttempts, sessions, users, type QuizQuestion } from "@/db/schema";
import { executeQuiz, settleExpiredAttempts } from "@/lib/quiz-engine";

async function unusedPort() {
  const server = createServer();
  return new Promise<number>((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", () => { const address = server.address(); const port = typeof address === "object" && address ? address.port : 0; server.close(() => resolve(port)); });
  });
}
async function main() {
  const tag = `owner-test-${randomUUID()}`;
  const ownerEmail = `${tag}@cephmed.invalid`;
  const ownerSub = `subject-${tag}`;
  const ids: string[] = [];
  const port = await unusedPort();
  const base = `http://127.0.0.1:${port}`;
  const questions: QuizQuestion[] = [0, 1, 2].map((i) => ({ question: `Question confidentielle ${i + 1} ${tag}`, options: ["Choix A", "Choix B", "Choix C"], correctAnswer: i, explanation: `Explication strictement privée ${tag}-${i}` }));
  let child: ChildProcess | null = null;
  let serverLog = "";
  const browser = await chromium.launch({ headless: true, args: ["--no-sandbox"] });
  const browserErrors: string[] = [];
  async function fixture(name: string, isDemo = false, owner = false, spoofedOwnerSession = false) {
    const [user] = await db.insert(users).values({ email: owner ? ownerEmail : `${randomUUID()}@cephmed.invalid`, googleId: isDemo ? null : owner ? ownerSub : randomUUID(), name, isDemo }).returning();
    ids.push(user.id);
    const token = randomBytes(32).toString("hex");
    await db.insert(sessions).values({ userId: user.id, tokenHash: createHash("sha256").update(token).digest("hex"), expiresAt: new Date(Date.now() + 60 * 60 * 1000), ownerAuthenticated: owner || spoofedOwnerSession });
    return { ...user, token };
  }
  async function contextFor(token?: string) {
    const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
    if (token) await context.addCookies([{ name: "cephmed_session", value: token, url: base, httpOnly: true, sameSite: "Lax" }]);
    return context;
  }
  async function scoredAttempt(userId: string, elapsed: number[]) {
    let state = await executeQuiz(tag, userId, { type: "start" });
    for (let i = 0; i < questions.length; i++) {
      await db.update(quizAttempts).set({ questionStartedAt: new Date(Date.now() - elapsed[i]) }).where(and(eq(quizAttempts.userId, userId), eq(quizAttempts.publicationId, tag)));
      state = await executeQuiz(tag, userId, { type: "answer", index: state.index, token: state.questionToken!, answer: i });
    }
    assert.equal(state.status, "completed");
  }
  async function replayAs(context: BrowserContext, request: Request) {
    return context.request.post(base + new URL(request.url()).pathname, {
      headers: { "Content-Type": request.headers()["content-type"] || "text/plain;charset=UTF-8", "Next-Action": request.headers()["next-action"], Origin: base },
      data: request.postData() || "[]",
    });
  }
  try {
    await mkdir("artifacts", { recursive: true });
    const owner = await fixture("Propriétaire de test", false, true);
    const fastest = await fixture("Camille — rapide");
    const slower = await fixture("Alex — plus lent");
    const demo = await fixture("Lecteur Démo", true);
    const impostor = await fixture("Autre compte Google", false, false, true);
    const late = await fixture("Participation expirée");
    await db.insert(publications).values({ id: tag, kind: "quiz", title: "Quiz de vérification privé temporaire", excerpt: "Données de test effacées à la fin du scénario.", content: "Une question toutes les 20 secondes.", topic: "Test", questions, published: true, createdAt: new Date("2000-01-01") });
    await scoredAttempt(fastest.id, [150, 220, 200]);
    await scoredAttempt(slower.id, [1200, 1600, 1500]);
    await scoredAttempt(demo.id, [0, 0, 0]);
    // A test-only server, bound to localhost, receives an explicit owner pin.
    // There is no test authentication endpoint or bypass in the application.
    child = spawn(process.execPath, ["node_modules/next/dist/bin/next", "start", "--hostname", "127.0.0.1", "--port", String(port)], {
      env: { ...process.env, OWNER_EMAIL: ownerEmail, OWNER_GOOGLE_SUB: ownerSub, APP_URL: base, GOOGLE_CLIENT_ID: "", GOOGLE_CLIENT_SECRET: "", ALLOW_DEMO_LOGIN: "false" },
      stdio: ["ignore", "pipe", "pipe"],
    });
    child.stdout?.on("data", (data) => { serverLog += String(data); });
    child.stderr?.on("data", (data) => { serverLog += String(data); });
    let ready = false;
    for (let i = 0; i < 120; i++) {
      if (child.exitCode !== null) throw new Error(`Test server stopped: ${serverLog}`);
      try { ready = (await fetch(base + "/api/health")).ok; } catch {}
      if (ready) break;
      await new Promise((r) => setTimeout(r, 150));
    }
    assert(ready, "Private test server must start");
    const anonymous = await contextFor();
    const ownerContext = await contextFor(owner.token);
    const readerContext = await contextFor(fastest.token);
    const demoContext = await contextFor(demo.token);
    const impostorContext = await contextFor(impostor.token);
    for (const context of [anonymous, readerContext, demoContext, impostorContext]) {
      const page = await context.newPage();
      page.on("pageerror", (error) => browserErrors.push(error.message));
      await page.goto(base + "/studio", { waitUntil: "networkidle" });
      await expect(page.getByRole("heading", { name: "Cette page s’est égarée.", exact: true })).toBeVisible();
      await expect(page.locator('a[href="/studio"]')).toHaveCount(0);
      assert(!(await page.content()).includes(questions[0].explanation));
      await page.close();
    }
    console.log("PASS Hidden studio for anonymous, reader, demo and wrong Google identity even with an owner-marked session");
    const beforePublication = await readerContext.request.get(`${base}/publications/${tag}`);
    const beforeHtml = await beforePublication.text();
    assert(!beforeHtml.includes(fastest.name.replace("—", "\\u2014")) || !beforeHtml.includes("ranking-row"));
    assert(!beforeHtml.includes(questions[0].question)); assert(!beforeHtml.includes("correctAnswer"));
    const noAuth = await anonymous.request.get(`${base}/api/quiz/${tag}`);
    assert.equal(noAuth.status(), 401);
    const crossOrigin = await readerContext.request.post(`${base}/api/quiz/${tag}`, { headers: { Origin: "https://attacker.invalid" }, data: { action: "start" } });
    assert.equal(crossOrigin.status(), 403);
    const ownerPlay = await ownerContext.request.post(`${base}/api/quiz/${tag}`, { headers: { Origin: base }, data: { action: "start" } });
    assert.equal(ownerPlay.status(), 403);
    console.log("PASS No private results before publication, API authentication and cross-origin protection");

    const page = await ownerContext.newPage();
    page.on("pageerror", (error) => browserErrors.push(error.message));
    const studioResponse = await page.goto(base + "/studio", { waitUntil: "networkidle" });
    await expect(page.getByRole("heading", { name: "Bienvenue dans votre studio." })).toBeVisible();
    assert(studioResponse?.headers()["cache-control"]?.includes("no-store"));
    assert.equal(studioResponse?.headers()["x-frame-options"], "DENY");
    await page.getByRole("button", { name: "Classement & corrections", exact: true }).click();
    await page.getByLabel("Choisir un quiz").selectOption(tag);
    const quickRow = page.getByRole("row").filter({ hasText: fastest.name });
    const slowRow = page.getByRole("row").filter({ hasText: slower.name });
    await expect(quickRow.locator(".owner-rank.first")).toHaveCount(1);
    await expect(slowRow.locator(".owner-rank")).toHaveText("2");
    await expect(page.getByRole("row").filter({ hasText: demo.name }).locator(".owner-rank")).toHaveText("—");
    await page.screenshot({ path: "artifacts/cephmed-private-ranking.png", fullPage: true });
    const correctionRequest = page.waitForRequest((request) => Boolean(request.headers()["next-action"]));
    await page.getByRole("button", { name: `Voir la correction de ${fastest.name}`, exact: true }).click();
    const capturedCorrection = await correctionRequest;
    await expect(page.locator(".private-question")).toHaveCount(3);
    await expect(page.locator(".private-question").first()).toContainText(questions[0].explanation);
    await page.screenshot({ path: "artifacts/cephmed-private-correction.png", fullPage: true });
    for (const context of [anonymous, readerContext, demoContext, impostorContext]) {
      const rejected = await replayAs(context, capturedCorrection);
      const body = await rejected.text();
      assert(!body.includes(questions[0].explanation), "Direct private action calls must never leak corrections");
      assert(!body.includes('"success":true'), "A non-owner must be refused by the private action");
    }
    await page.getByRole("button", { name: "Fermer la fenêtre", exact: true }).click();
    console.log("PASS Correctness/speed private ranking, detailed automatic corrections and action-level ownership checks");

    await executeQuiz(tag, late.id, { type: "start" });
    await page.getByRole("button", { name: "Mes publications", exact: true }).click();
    const publicationRow = page.locator(".studio-row").filter({ hasText: "Quiz de vérification privé temporaire" });
    await publicationRow.getByRole("button", { name: "Publier le classement", exact: true }).click();
    const publishRequest = page.waitForRequest((request) => Boolean(request.headers()["next-action"]));
    await page.getByRole("dialog").getByRole("button", { name: "Publier le classement", exact: true }).click();
    const capturedPublish = await publishRequest;
    await expect(page.locator(".toast-visible")).toContainText("encore en cours");
    let [post] = await db.select().from(publications).where(eq(publications.id, tag));
    assert.equal(post.resultsPublished, false);
    for (const context of [anonymous, readerContext, impostorContext]) await replayAs(context, capturedPublish);
    [post] = await db.select().from(publications).where(eq(publications.id, tag));
    assert.equal(post.resultsPublished, false, "Only the owner may publish");
    await page.getByRole("dialog").getByRole("button", { name: "Pas encore", exact: true }).click();
    await db.update(quizAttempts).set({ questionStartedAt: new Date(Date.now() - 65_000) }).where(and(eq(quizAttempts.publicationId, tag), eq(quizAttempts.userId, late.id)));
    await settleExpiredAttempts(tag);
    await publicationRow.getByRole("button", { name: "Publier le classement", exact: true }).click();
    await page.getByRole("dialog").getByRole("button", { name: "Publier le classement", exact: true }).click();
    await expect(page.locator(".toast-visible")).toContainText("Le classement est public");
    [post] = await db.select().from(publications).where(eq(publications.id, tag));
    assert.equal(post.resultsPublished, true);
    const publicPage = await anonymous.newPage();
    const publicResponse = await publicPage.goto(`${base}/publications/${tag}`, { waitUntil: "networkidle" });
    const publicHtml = await publicResponse!.text();
    await expect(publicPage.getByRole("heading", { name: "Les résultats sont là !" })).toBeVisible();
    await expect(publicPage.locator(".ranking-row")).toHaveCount(3);
    await expect(publicPage.locator(".ranking-row").nth(0)).toContainText(fastest.name);
    await expect(publicPage.locator(".ranking-row").nth(1)).toContainText(slower.name);
    for (const privateValue of ["correctAnswer", "answerTimesMs", "selectedAnswer", questions[0].question, questions[0].explanation, demo.name]) assert(!publicHtml.includes(privateValue), `Private value leaked after publication: ${privateValue}`);
    const complete = await readerContext.request.get(`${base}/api/quiz/${tag}`);
    const completeData = await complete.json();
    assert.equal(completeData.status, "completed"); assert.equal(completeData.question, null); assert(!Object.hasOwn(completeData, "score"));
    assert.deepEqual(browserErrors, []);
    console.log("PASS Active-quiz publication guard, owner-only publication and permanently private answer keys");
  } finally {
    await browser.close();
    if (child && child.exitCode === null) {
      await new Promise<void>((resolve) => {
        const kill = setTimeout(() => { child?.kill("SIGKILL"); }, 5000);
        child!.once("exit", () => { clearTimeout(kill); resolve(); });
        child!.kill("SIGTERM");
      });
    }
    await db.delete(publications).where(eq(publications.id, tag));
    if (ids.length) await db.delete(users).where(inArray(users.id, ids));
    await pool.end();
    console.log("Private test server stopped; owner and reader fixtures removed.");
  }
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
