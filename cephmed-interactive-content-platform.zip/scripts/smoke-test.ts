import "dotenv/config";
import { chromium, expect } from "@playwright/test";
import { mkdir } from "node:fs/promises";
import assert from "node:assert/strict";
import { eq } from "drizzle-orm";
import { db, pool } from "@/db";
import { users, subscriptions } from "@/db/schema";

async function main() {
  const base = process.env.CEPHMED_TEST_URL || "http://127.0.0.1:3000";
  const testName = `Lecteur découverte ${Date.now()}`;
  const testEmail = `test-${Date.now()}@cephmed.invalid`;
  const commentText = `Une belle invitation à ralentir et à prendre soin de son sommeil. Test ${Date.now()}.`;
  const browser = await chromium.launch({ headless: true, args: ["--no-sandbox"] });
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  const page = await context.newPage();
  const errors: string[] = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await mkdir("artifacts", { recursive: true });
  try {
    await page.goto(base, { waitUntil: "networkidle" });
    await page.evaluate(() => document.fonts.ready);
    await expect(page.getByRole("heading", { level: 1 })).toContainText("Un peu de savoir.");
    await expect(page.locator(".publication-card")).toHaveCount(3);
    await page.screenshot({ path: "artifacts/cephmed-desktop.png", fullPage: true });
    await page.setViewportSize({ width: 1440, height: 900 });
    await page.screenshot({ path: "artifacts/cephmed-first-screen.png" });
    console.log("PASS Home page and local visual assets");

    await page.getByRole("button", { name: "Conseils", exact: true }).click();
    await expect(page.locator(".publication-card")).toHaveCount(2);
    await page.getByRole("button", { name: "Livres", exact: true }).click();
    await expect(page.locator(".publication-card")).toHaveCount(2);
    await page.getByRole("button", { name: "Quiz", exact: true }).click();
    await expect(page.locator(".publication-card")).toHaveCount(2);
    await page.getByRole("button", { name: "Tout explorer", exact: true }).click();
    await expect(page.locator(".publication-card")).toHaveCount(3);
    await page.getByRole("button", { name: "Rechercher une publication", exact: true }).click();
    await page.getByRole("textbox", { name: "Votre recherche", exact: true }).fill("sommeil");
    await page.getByRole("button", { name: "Rechercher", exact: true }).click();
    await expect(page.locator(".publication-card")).toHaveCount(2);
    await expect(page.locator(".card-title-link").first()).toContainText("Mieux dormir");
    console.log("PASS Categories and search");

    await page.goto(`${base}/publications/les-petits-rituels-pour-mieux-dormir`, { waitUntil: "networkidle" });
    await expect(page.getByRole("heading", { name: "Retrouver un rythme régulier", exact: true })).toBeVisible();
    await page.getByRole("button", { name: "Se connecter", exact: true }).click();
    await page.getByRole("button", { name: "Essayer le mode découverte" }).click();
    await page.getByLabel("Comment vous appeler ?").fill(testName);
    await page.getByRole("button", { name: "Entrer en mode découverte" }).click();
    await expect(page.locator(".account-name")).toHaveText("Lecteur", { timeout: 15000 });
    await expect(page.getByRole("dialog")).toHaveCount(0);
    console.log("PASS Demo reader session (never an owner)");

    await page.getByRole("textbox", { name: "Votre commentaire", exact: true }).fill(commentText);
    await page.getByRole("button", { name: "Publier mon avis" }).click();
    await expect(page.locator(".comment-content").filter({ hasText: commentText })).toBeVisible();
    await page.getByRole("button", { name: "Enregistrer dans mes favoris", exact: true }).click();
    await expect(page.getByRole("button", { name: "Retirer de mes favoris", exact: true })).toHaveAttribute("aria-pressed", "true");
    await page.reload({ waitUntil: "networkidle" });
    await expect(page.getByRole("button", { name: "Retirer de mes favoris", exact: true })).toHaveAttribute("aria-pressed", "true");
    await expect(page.getByText(commentText, { exact: true })).toBeVisible();
    console.log("PASS Persistent comments and bookmarks");

    const quizResponse = await page.goto(`${base}/publications/connaissez-vous-vraiment-votre-cerveau`, { waitUntil: "networkidle" });
    const quizHtml = await quizResponse!.text();
    assert(!quizHtml.includes("correctAnswer"), "Answer keys must never be serialized to readers");
    assert(!quizHtml.includes("Quel rôle le sommeil joue-t-il dans la mémoire"), "Future questions must not be present in the initial document");
    await page.getByRole("button", { name: "Commencer le quiz", exact: true }).click();
    await expect(page.locator(".timed-quiz-panel")).toHaveAttribute("data-question-index", "0");
    await expect(page.getByRole("timer")).toBeVisible();
    const firstSnapshot = await page.evaluate(async () => { const response = await fetch("/api/quiz/connaissez-vous-vraiment-votre-cerveau", { cache: "no-store" }); if (!response.ok) throw new Error("Authenticated quiz state request failed"); return response.json(); });
    await page.screenshot({ path: "artifacts/cephmed-timed-quiz.png", fullPage: true });
    await page.reload({ waitUntil: "networkidle" });
    await expect(page.locator(".timed-quiz-panel")).toHaveAttribute("data-question-index", "0");
    const reloadedSnapshot = await page.evaluate(async () => { const response = await fetch("/api/quiz/connaissez-vous-vraiment-votre-cerveau", { cache: "no-store" }); if (!response.ok) throw new Error("Authenticated quiz reload request failed"); return response.json(); });
    assert.equal(reloadedSnapshot.deadlineMs, firstSnapshot.deadlineMs, "Reload must not reset the deadline");
    await expect(page.locator(".timed-quiz-panel")).toHaveAttribute("data-question-index", "1", { timeout: 24000 });
    await expect(page.getByRole("button", { name: /Précédent|Vérifier mes réponses|Revenir/ })).toHaveCount(0);
    const staleReply = await page.evaluate(async (token: string) => { const response = await fetch("/api/quiz/connaissez-vous-vraiment-votre-cerveau", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "answer", questionIndex: 0, questionToken: token, answer: 1, score: 99, elapsedMs: 0 }) }); if (!response.ok) throw new Error("Authenticated stale-answer request failed"); return response.json(); }, firstSnapshot.questionToken);
    assert.equal(staleReply.index, 1, "An expired answer must not be applied to the next question");
    for (const [index, choice] of [[1, 2], [2, 0], [3, 3], [4, 1]]) {
      await expect(page.locator(".timed-quiz-panel")).toHaveAttribute("data-question-index", String(index));
      await page.locator(".quiz-option").nth(choice).click();
    }
    await expect(page.getByRole("heading", { name: /Votre participation.*est bien enregistrée/ })).toBeVisible();
    await expect(page.locator(".score-number")).toHaveCount(0);
    await page.reload({ waitUntil: "networkidle" });
    await expect(page.getByText("En attente de la publication du classement", { exact: true })).toBeVisible();
    await expect(page.getByRole("button", { name: "Commencer le quiz", exact: true })).toHaveCount(0);
    console.log("PASS Real 20-second expiry, automatic sequential answers, reload persistence and private corrections");

    await page.goto(`${base}/mon-espace`, { waitUntil: "networkidle" });
    await expect(page.locator(".publication-card")).toHaveCount(1);
    await page.getByRole("button", { name: /Mes participations/ }).click();
    await expect(page.getByText("Résultats à venir", { exact: true })).toBeVisible();
    await page.getByRole("button", { name: /Mes favoris/ }).click();
    await page.getByRole("button", { name: "Retirer de mes favoris", exact: true }).click();
    await expect(page.getByRole("heading", { name: "Gardez les idées qui vous inspirent." })).toBeVisible();
    await page.goto(`${base}/studio`, { waitUntil: "networkidle" });
    await expect(page.getByRole("heading", { name: "Cette page s’est égarée." })).toBeVisible();
    await expect(page.locator('a[href="/studio"]')).toHaveCount(0);
    await expect(page.getByRole("button", { name: "Nouvelle publication" })).toHaveCount(0);
    console.log("PASS Reader space and owner-only access gate");

    await page.goto(`${base}/publications/les-petits-rituels-pour-mieux-dormir`, { waitUntil: "networkidle" });
    await page.locator(".comment").filter({ hasText: commentText }).getByRole("button", { name: "Supprimer" }).click();
    await page.getByRole("dialog").getByRole("button", { name: "Supprimer", exact: true }).click();
    await expect(page.getByText(commentText, { exact: true })).toHaveCount(0);
    console.log("PASS Comment deletion");

    await page.goto(base, { waitUntil: "networkidle" });
    await page.getByRole("textbox", { name: "Votre adresse e-mail", exact: true }).fill(testEmail);
    await page.getByRole("checkbox", { name: "J’accepte de recevoir les nouvelles de CephMed." }).check();
    await page.getByRole("button", { name: "M’inscrire à la newsletter", exact: true }).click();
    await expect(page.getByText("Vous êtes sur la liste !", { exact: true })).toBeVisible();
    const [subscription] = await db.select().from(subscriptions).where(eq(subscriptions.email, testEmail));
    assert(subscription, "Newsletter consent must persist in PostgreSQL");
    console.log("PASS Newsletter consent and database persistence");

    await page.locator(".account-button").click();
    await page.getByRole("button", { name: "Se déconnecter", exact: true }).click();
    await expect(page.getByRole("button", { name: "Se connecter", exact: true })).toBeVisible();
    await page.reload({ waitUntil: "networkidle" });
    await expect(page.getByRole("button", { name: "Se connecter", exact: true })).toBeVisible();
    console.log("PASS Session destruction");

    const mobile = await browser.newPage({ viewport: { width: 390, height: 844 }, isMobile: true, deviceScaleFactor: 1, hasTouch: true });
    await mobile.goto(base, { waitUntil: "networkidle" });
    await mobile.evaluate(() => document.fonts.ready);
    assert(await mobile.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), "No horizontal scrolling on mobile");
    await mobile.screenshot({ path: "artifacts/cephmed-mobile.png", fullPage: true });
    await mobile.getByRole("button", { name: "Ouvrir le menu" }).click();
    await mobile.locator(".mobile-nav").getByRole("link", { name: "Bibliothèque", exact: true }).click();
    await expect(mobile.getByRole("heading", { level: 1 })).toContainText("Des livres, des horizons.");
    assert(await mobile.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), "No library overflow on mobile");
    console.log("PASS Mobile layout and mobile navigation");

    for (const path of ["/conseils", "/bibliotheque", "/quiz", "/a-propos", "/confidentialite", "/mon-espace"]) {
      const response = await page.goto(base + path, { waitUntil: "networkidle" });
      assert.equal(response?.status(), 200, `Route ${path} must respond successfully`);
    }
    const missing = await page.goto(`${base}/publications/a-publication-that-does-not-exist`, { waitUntil: "networkidle" });
    assert([200, 404].includes(missing?.status() ?? 0), "Next.js may stream its not-found boundary with status 200");
    await expect(page.getByRole("heading", { name: "Cette page s’est égarée.", exact: true })).toBeVisible();
    await expect(page.locator('meta[name="robots"][content*="noindex"]').first()).toHaveAttribute("content", /noindex/);
    const health = await context.request.get(`${base}/api/health`);
    assert.deepEqual(await health.json(), { ok: true });
    assert.deepEqual(errors, [], "No browser runtime errors");
    console.log("PASS Public routes, not-found handling, healthcheck and no browser errors");
  } finally {
    await db.delete(users).where(eq(users.name, testName));
    await db.delete(subscriptions).where(eq(subscriptions.email, testEmail));
    await browser.close();
    await pool.end();
    console.log("Temporary test data cleaned up.");
  }
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
