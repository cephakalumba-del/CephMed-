import "dotenv/config";
import assert from "node:assert/strict";
import { createHash, randomUUID } from "node:crypto";
import { and, eq, inArray } from "drizzle-orm";
import { db, pool } from "@/db";
import { publications, quizAttempts, siteSettings, users, type QuizQuestion } from "@/db/schema";
import { advanceExpiredQuestions, executeQuiz, settleExpiredAttempts, type StoredAttempt } from "@/lib/quiz-engine";
import { QUESTION_TIME_MS, rankQuizAttempts } from "@/lib/quiz-rules";
import { bindVerifiedOwner, isOwnerIdentity } from "@/lib/owner";

async function main() {
  const tag = `test-timed-${randomUUID()}`;
  const questions: QuizQuestion[] = [0, 1, 2].map((i) => ({ question: `PRIVATE_QUESTION_${i}_${tag}`, options: ["A", "B", "C"], correctAnswer: i, explanation: `PRIVATE_EXPLANATION_${i}` }));
  const ids: string[] = [];
  const savedEmail = process.env.OWNER_EMAIL;
  const savedSub = process.env.OWNER_GOOGLE_SUB;
  const email = `${tag}@cephmed.invalid`;
  const pinKey = `owner-google-identity:${createHash("sha256").update(email).digest("hex")}`;
  try {
    await db.insert(publications).values({ id: tag, kind: "quiz", title: "Test technique temporaire", excerpt: "Données de test supprimées automatiquement.", content: "Test", topic: "Test", questions, published: true, createdAt: new Date("2000-01-01") });
    for (let i = 0; i < 2; i++) {
      const [user] = await db.insert(users).values({ email: `${i}-${email}`, name: `Test ${tag}`, isDemo: true }).returning(); ids.push(user.id);
    }
    const ready = await executeQuiz(tag, ids[0], { type: "read" });
    assert.equal(ready.status, "ready"); assert.equal(ready.question, null);
    const first = await executeQuiz(tag, ids[0], { type: "start" });
    assert.equal(first.index, 0); assert.equal(first.question?.question, questions[0].question);
    assert(!JSON.stringify(first).includes(questions[1].question));
    for (const key of ["correctAnswer", "explanation", "answers", "score", "answerTimesMs"]) assert(!Object.hasOwn(first, key));
    const repeat = await executeQuiz(tag, ids[0], { type: "start" });
    assert.equal(repeat.deadlineMs, first.deadlineMs); assert.equal(repeat.questionToken, first.questionToken);
    assert(first.deadlineMs! - first.serverNowMs <= QUESTION_TIME_MS);
    const earlySkip = await executeQuiz(tag, ids[0], { type: "answer", index: 0, token: first.questionToken!, answer: null });
    assert.equal(earlySkip.index, 0, "An early timeout request cannot skip a question");
    const future = await executeQuiz(tag, ids[0], { type: "answer", index: 1, token: first.questionToken!, answer: 1 });
    assert.equal(future.index, 0, "Future questions cannot be answered in advance");
    const wrongToken = await executeQuiz(tag, ids[0], { type: "answer", index: 0, token: randomUUID(), answer: 0 });
    assert.equal(wrongToken.index, 0, "The current question token is mandatory");
    console.log("PASS Server deadlines, sequential delivery and no prefetching or early skipping");

    const concurrent = await Promise.all([0, 1].map(() => executeQuiz(tag, ids[0], { type: "answer", index: 0, token: first.questionToken!, answer: 0 })));
    assert(concurrent.every((s) => s.index === 1));
    let [stored] = await db.select().from(quizAttempts).where(and(eq(quizAttempts.publicationId, tag), eq(quizAttempts.userId, ids[0])));
    assert.equal(stored.answers.length, 1); assert.equal(stored.score, 1);
    const resumed = await executeQuiz(tag, ids[0], { type: "read" });
    assert.equal(resumed.questionToken, concurrent[0].questionToken);
    const originalDeadline = resumed.deadlineMs;
    await new Promise((resolve) => setTimeout(resolve, 120));
    assert.equal((await executeQuiz(tag, ids[0], { type: "start" })).deadlineMs, originalDeadline);
    await db.update(quizAttempts).set({ questionStartedAt: new Date(Date.now() - 20_100) }).where(eq(quizAttempts.id, stored.id));
    const late = await executeQuiz(tag, ids[0], { type: "answer", index: 1, token: resumed.questionToken!, answer: 1 });
    assert.equal(late.index, 2); assert.equal(late.status, "in_progress");
    [stored] = await db.select().from(quizAttempts).where(eq(quizAttempts.id, stored.id));
    assert.deepEqual(stored.answers, [0, -1]); assert.equal(stored.answerTimesMs[1], 20_000); assert.equal(stored.score, 1);
    const done = await executeQuiz(tag, ids[0], { type: "answer", index: 2, token: late.questionToken!, answer: 2 });
    assert.equal(done.status, "completed"); assert.equal(done.question, null);
    assert.equal((await executeQuiz(tag, ids[0], { type: "start" })).status, "completed");
    assert.equal((await executeQuiz(tag, ids[0], { type: "answer", index: 0, token: first.questionToken!, answer: 0 })).status, "completed");
    [stored] = await db.select().from(quizAttempts).where(eq(quizAttempts.id, stored.id));
    assert.deepEqual(stored.answers, [0, -1, 2]); assert.equal(stored.score, 2); assert.equal(stored.timedOutCount, 1);
    assert.equal(stored.correctTimeMs, stored.answerTimesMs[0] + stored.answerTimesMs[2]);
    assert.equal(stored.totalTimeMs, stored.correctTimeMs! + 20_000);
    assert.equal((await db.select().from(quizAttempts).where(and(eq(quizAttempts.publicationId, tag), eq(quizAttempts.userId, ids[0])))).length, 1);
    console.log("PASS Concurrent clicks, replay protection, late answers rejected, immutable completed attempts");

    await executeQuiz(tag, ids[1], { type: "start" });
    await db.update(quizAttempts).set({ questionStartedAt: new Date(Date.now() - 40_500) }).where(and(eq(quizAttempts.publicationId, tag), eq(quizAttempts.userId, ids[1])));
    const offline = await executeQuiz(tag, ids[1], { type: "read" });
    assert.equal(offline.index, 2); assert(offline.deadlineMs! - offline.serverNowMs < 19_600);
    await db.update(quizAttempts).set({ questionStartedAt: new Date(Date.now() - 20_100) }).where(and(eq(quizAttempts.publicationId, tag), eq(quizAttempts.userId, ids[1])));
    await settleExpiredAttempts(tag);
    const [expired] = await db.select().from(quizAttempts).where(and(eq(quizAttempts.publicationId, tag), eq(quizAttempts.userId, ids[1])));
    assert.equal(expired.status, "completed"); assert.deepEqual(expired.answers, [-1, -1, -1]); assert.equal(expired.totalTimeMs, 60_000); assert.equal(expired.correctTimeMs, 0);
    const boundary: StoredAttempt = { ...stored, protocolVersion: 2, status: "in_progress", currentIndex: 0, questionStartedAt: new Date(100_000), questionToken: randomUUID(), answers: [], answerTimesMs: [], score: 0, correctTimeMs: 0, totalTimeMs: 0, timedOutCount: 0, completedAt: null };
    assert.equal(advanceExpiredQuestions(boundary, questions, 119_999), false);
    assert.equal(advanceExpiredQuestions(boundary, questions, 120_000), true);
    assert.equal(boundary.currentIndex, 1); assert.deepEqual(boundary.answers, [-1]);
    advanceExpiredQuestions(boundary, questions, 180_000);
    assert.equal(boundary.completedAt?.getTime(), 160_000); assert.equal(boundary.status, "completed");
    console.log("PASS Exact 20-second boundary, offline progression and automatic abandoned-quiz correction");

    const common = { publicationId: tag, status: "completed", protocolVersion: 2, isDemo: false, createdAt: "2026-01-01" };
    const ranked = rankQuizAttempts([
      { ...common, id: "many-correct", score: 3, correctTimeMs: 59_000 },
      { ...common, id: "quick", score: 2, correctTimeMs: 2200 },
      { ...common, id: "tie", score: 2, correctTimeMs: 2200 },
      { ...common, id: "slower", score: 2, correctTimeMs: 4000 },
      { ...common, id: "demo", score: 99, correctTimeMs: 1, isDemo: true },
      { ...common, id: "legacy", score: 99, correctTimeMs: null, protocolVersion: 1 },
      { ...common, id: "running", score: 99, correctTimeMs: 1, status: "in_progress" },
      { ...common, id: "different-quiz", publicationId: "other", score: 1, correctTimeMs: 5 },
    ]);
    const rank = (id: string) => ranked.find((a) => a.id === id)?.rank;
    assert.equal(rank("many-correct"), 1); assert.equal(rank("quick"), 2); assert.equal(rank("tie"), 2); assert.equal(rank("slower"), 4);
    assert.equal(rank("demo"), null); assert.equal(rank("legacy"), null); assert.equal(rank("running"), null); assert.equal(rank("different-quiz"), 1);
    console.log("PASS Ranking prioritizes correctness then speed, exact ties and excluded demo/legacy attempts");

    delete process.env.OWNER_EMAIL; delete process.env.OWNER_GOOGLE_SUB;
    const identity = { email, googleId: `google-${tag}`, isDemo: false };
    assert.equal(await isOwnerIdentity(identity), false);
    process.env.OWNER_EMAIL = email;
    assert.equal(await isOwnerIdentity(identity), false, "An unpinned identity is not an owner");
    await bindVerifiedOwner({ ...identity, isDemo: true });
    assert.equal(await isOwnerIdentity(identity), false, "Demo identities cannot claim ownership");
    await bindVerifiedOwner(identity);
    assert.equal(await isOwnerIdentity(identity), true);
    await bindVerifiedOwner({ ...identity, googleId: "different-subject" });
    assert.equal(await isOwnerIdentity({ ...identity, googleId: "different-subject" }), false);
    assert.equal(await isOwnerIdentity({ ...identity, isDemo: true }), false);
    assert.equal(await isOwnerIdentity({ ...identity, email: "someone-else@cephmed.invalid" }), false);
    assert.equal(await isOwnerIdentity({ ...identity, googleId: null }), false);
    process.env.OWNER_GOOGLE_SUB = "explicit-pin";
    assert.equal(await isOwnerIdentity(identity), false);
    assert.equal(await isOwnerIdentity({ ...identity, googleId: "explicit-pin" }), true);
    console.log("PASS Fail-closed ownership, verified-email allowlist, immutable subject pin and demo denial");
  } finally {
    if (savedEmail === undefined) delete process.env.OWNER_EMAIL; else process.env.OWNER_EMAIL = savedEmail;
    if (savedSub === undefined) delete process.env.OWNER_GOOGLE_SUB; else process.env.OWNER_GOOGLE_SUB = savedSub;
    await db.delete(publications).where(eq(publications.id, tag));
    if (ids.length) await db.delete(users).where(inArray(users.id, ids));
    await db.delete(siteSettings).where(eq(siteSettings.key, pinKey));
    await pool.end();
    console.log("Timed-quiz fixtures removed.");
  }
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
