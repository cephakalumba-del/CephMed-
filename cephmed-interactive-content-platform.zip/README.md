# CephMed

Un peu de savoir. Beaucoup de sens. Application éditoriale française avec **Next.js App Router, PostgreSQL et Drizzle ORM**.

## Prise en main

- Accueil éditorial, conseils, bibliothèque, recherche, filtres et favoris.
- Comptes Google, commentaires signés et espace lecteur.
- **Quiz de 20 secondes par question**, dans l’ordre, sans retour ni pause.
- Réponse validée dès le clic ; question expirée passée automatiquement. Enregistrement, délai officiel et correction côté serveur.
- Classement privé par bonnes réponses décroissantes, puis temps cumulé sur les bonnes réponses croissant ; égalités exactes ex æquo.
- Studio du propriétaire masqué aux visiteurs, contrôlé côté serveur, avec rapports, corrections individuelles, CSV et publication manuelle du seul classement final.
- Polices et illustrations locales, interface responsive, newsletter avec enregistrement du consentement (pas de service d’envoi configuré).

**Le guide complet pour GitHub, la mise en ligne et la sécurité est dans [GITHUB-ET-SECURITE.md](./GITHUB-ET-SECURITE.md).** Il contient une méthode GitHub Desktop et les commandes Git.

## Configuration

Copiez `.env.example` vers `.env` localement et renseignez vos valeurs. `.env` et ses variantes sont ignorés par Git. En production, utilisez les variables sécurisées de l’hébergement.

| Variable | Utilité |
| --- | --- |
| `DATABASE_URL` | Connexion PostgreSQL privée |
| `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` | Client OAuth Google Web |
| `OWNER_EMAIL` | Adresse Google exacte de l’unique propriétaire, aucun défaut |
| `OWNER_GOOGLE_SUB` | Verrouillage explicite optionnel sur votre identifiant Google immuable |
| `APP_URL` | URL canonique HTTPS sans slash final |
| `ALLOW_DEMO_LOGIN=false` | Désactiver la démonstration à l’ouverture publique |

Google Cloud doit autoriser la redirection `APP_URL/api/auth/callback/google`. Seuls `openid email profile` sont demandés, sans accès à Gmail. Le premier login Google vérifié correspondant à `OWNER_EMAIL` lie l’identité propriétaire dans PostgreSQL. Ce lien ne peut pas être remplacé par un autre utilisateur. L’adresse de l’hébergeur et la base doivent être administrées uniquement par vous et vos administrateurs de confiance.

Après configuration, reconnectez-vous avec votre compte Google puis ouvrez **Mon studio** dans le menu de votre compte. Pour les autres comptes et les visiteurs, `/studio` affiche une page introuvable. La session propriétaire dure huit heures et une session lecteur quatorze jours. Activez la validation en deux étapes sur Google et GitHub ; l’application ne crée pas un second facteur indépendant.

## Base et exécution locale

```bash
npm ci
npx drizzle-kit push
npm run dev
```

Le schéma est défini dans `src/db/schema.ts`. Six publications d’exemple sont ajoutées une seule fois. Les changements de textes de quiz ne mettent à jour que les exemples non modifiés ; les publications et les participations existantes sont conservées.

Les anciens quiz non chronométrés sont archivés hors classement chronométré, sans temps fictif. Les comptes de démonstration ne sont jamais propriétaires et sont exclus du classement public officiel.

## Moteur chronométré

`src/lib/quiz-engine.ts` est un moteur transactionnel utilisant l’horloge PostgreSQL. Il verrouille la publication puis la participation, vérifie l’ordre et le jeton de question, rejette les réponses tardives et empêche les doubles envois. Un rechargement ne réinitialise jamais la date de début. En cas d’absence, les échéances continuent et sont matérialisées au prochain accès serveur. Le propriétaire voit les tentatives abandonnées corrigées automatiquement en ouvrant ou actualisant le studio.

L’API `/api/quiz/[id]` authentifie chaque requête ; les écritures vérifient l’origine. Le client reçoit seulement la question courante et son échéance, jamais les questions futures, les choix corrects ou les scores privés. La correction détaillée reste réservée au propriétaire même après publication du classement.

## Validation

```bash
npx next typegen
npm exec tsc -- --noEmit --pretty false
npm run build
```

La route `/api/health` vérifie PostgreSQL.

Tests sur une **base locale de test**, pas sur la production :

```bash
npx tsx scripts/timed-quiz-test.ts
npx playwright install --with-deps chromium
# Le serveur local doit être démarré pour le parcours lecteur :
npx tsx scripts/smoke-test.ts
# Après npm run build ; ce test lance et arrête son serveur privé temporaire :
npx tsx scripts/owner-security-test.ts
```

- Test du moteur : ordre, échéances exactes, reprises, expirations hors ligne, doubles envois, réponses tardives, calcul et classement, liaison de l’identité propriétaire.
- Parcours lecteur : connexion, commentaires, favoris, expiration réelle de 20 secondes, quiz séquentiel, résultats privés, mobile et routes protégées. Il nécessite le mode découverte (pas de secrets Google et `ALLOW_DEMO_LOGIN` non égal à `false`). `CEPHMED_TEST_URL` remplace l’URL locale par défaut.
- Test du studio : serveur temporaire en localhost, comptes et cookies de fixtures, classement, corrections, publication manuelle, protection des actions et des données. Aucun contournement d’authentification n’est ajouté à l’application. Les fixtures sont supprimées et le processus temporaire est arrêté après le test.

## GitHub et production

`.gitignore` exclut `.env`, clés, builds, dépendances, captures et exports privés. Le dépôt privé est recommandé. Les données PostgreSQL ne sont pas synchronisées dans GitHub. **GitHub Pages n’héberge pas le backend de cette application.** Voir le guide dédié pour GitHub Desktop, la ligne de commande, l’hébergement Next.js/PostgreSQL et la checklist sécurité.

Avant mise en ligne publique : compléter les mentions légales et le contact, configurer les sauvegardes et le suivi des dépendances, désactiver la démonstration, protéger les comptes par un second facteur et utiliser exclusivement HTTPS. Les contenus santé sont informatifs ; les couvertures des livres sont des compositions éditoriales originales, sans téléchargement de copie non autorisée.
