import { createHash } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { siteSettings } from "@/db/schema";

type Identity = { email: string; googleId: string | null; isDemo: boolean };
const ownerEmail = () => process.env.OWNER_EMAIL?.trim().toLowerCase() || "";
const identityKey = () => `owner-google-identity:${createHash("sha256").update(ownerEmail()).digest("hex")}`;
function eligible(identity: Identity) {
  return !identity.isDemo && Boolean(identity.googleId) && Boolean(ownerEmail()) && identity.email.toLowerCase() === ownerEmail();
}
// Called only after signature, issuer, audience, nonce and email verification
// in the Google callback. No public action can assign or change the owner.
export async function bindVerifiedOwner(identity: Identity) {
  if (!eligible(identity)) return;
  const configuredSubject = process.env.OWNER_GOOGLE_SUB?.trim();
  if (configuredSubject && identity.googleId !== configuredSubject) return;
  await db.insert(siteSettings).values({ key: identityKey(), value: identity.googleId! }).onConflictDoNothing();
}
export async function isOwnerIdentity(identity: Identity) {
  if (!eligible(identity)) return false;
  const configuredSubject = process.env.OWNER_GOOGLE_SUB?.trim();
  if (configuredSubject) return identity.googleId === configuredSubject;
  const [pin] = await db.select({ value: siteSettings.value }).from(siteSettings).where(eq(siteSettings.key, identityKey())).limit(1);
  return Boolean(pin && pin.value === identity.googleId);
}
