import { and, eq, desc, count, sql } from "drizzle-orm";
import { db } from "@/db";
import { publications, comments, users, quizAttempts, bookmarks } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { requireOwner } from "@/lib/auth";
import { rankQuizAttempts, TIMED_QUIZ_VERSION } from "@/lib/quiz-rules";
import { settleExpiredAttempts } from "@/lib/quiz-engine";
import type { Publication, Reader, Comment, Attempt, Result, OwnerStats, OwnerAttemptDetail } from "@/lib/types";

function serializePublication(post: typeof publications.$inferSelect, commentCount = 0, participantCount = 0, owner = false): Publication {
  return { ...post, createdAt: post.createdAt.toISOString(), commentCount, participantCount,
    readingTime: post.kind === "quiz" ? Math.max(1, Math.ceil((post.questions?.length ?? 0) / 3)) : post.readingTime,
    questionCount: post.questions?.length ?? 0, questions: owner ? post.questions : null };
}
export async function getPublications(owner = false): Promise<Publication[]> {
  if (owner) await requireOwner();
  await ensureSeeded();
  const list = await db.select().from(publications).where(owner ? undefined : eq(publications.published, true)).orderBy(desc(publications.createdAt));
  const counts = await db.select({ id: comments.publicationId, value: count() }).from(comments).groupBy(comments.publicationId);
  const attempts = await db.select({ id: quizAttempts.publicationId, value: count() }).from(quizAttempts).groupBy(quizAttempts.publicationId);
  return list.map((p) => serializePublication(p, counts.find((c) => c.id === p.id)?.value ?? 0, attempts.find((a) => a.id === p.id)?.value ?? 0, owner));
}
export async function getSavedIds(reader: Reader | null) {
  if (!reader) return [];
  return (await db.select({ id: bookmarks.publicationId }).from(bookmarks).where(eq(bookmarks.userId, reader.id))).map((r) => r.id);
}
export async function getPublicationDetail(id: string, reader: Reader | null) {
  await ensureSeeded();
  if (reader?.isOwner) await requireOwner();
  const [raw] = await db.select().from(publications).where(and(eq(publications.id, id), reader?.isOwner ? undefined : eq(publications.published, true))).limit(1);
  if (!raw) return null;
  const commentList = await db.select({ id: comments.id, body: comments.body, createdAt: comments.createdAt, name: users.name, avatar: users.avatar, userId: users.id, isDemo: users.isDemo }).from(comments).innerJoin(users, eq(comments.userId, users.id)).where(eq(comments.publicationId, id)).orderBy(desc(comments.createdAt));
  const attemptRows = reader ? await db.select({ id: quizAttempts.id, createdAt: quizAttempts.createdAt, status: quizAttempts.status, protocolVersion: quizAttempts.protocolVersion }).from(quizAttempts).where(and(eq(quizAttempts.publicationId, id), eq(quizAttempts.userId, reader.id))).limit(1) : [];
  // Only an explicitly published final ranking is public. Never expose answer
  // keys, individual selections or per-question timings on the article page.
  const ranking = raw.resultsPublished ? await db.select({ id: quizAttempts.id, publicationId: quizAttempts.publicationId, name: users.name, score: quizAttempts.score, correctTimeMs: quizAttempts.correctTimeMs, createdAt: quizAttempts.createdAt, isDemo: users.isDemo, protocolVersion: quizAttempts.protocolVersion, status: quizAttempts.status })
    .from(quizAttempts).innerJoin(users, eq(users.id, quizAttempts.userId))
    .where(and(eq(quizAttempts.publicationId, id), eq(quizAttempts.status, "completed"), eq(quizAttempts.protocolVersion, TIMED_QUIZ_VERSION), eq(users.isDemo, false))) : [];
  const ranked = rankQuizAttempts(ranking.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() })));
  const results: Result[] = ranked.filter((r) => r.rank !== null).map((r) => ({ name: r.name, score: r.score, createdAt: r.createdAt, rank: r.rank!, correctTimeMs: r.correctTimeMs! }));
  const [stats] = await db.select({ value: count() }).from(quizAttempts).where(eq(quizAttempts.publicationId, id));
  const commentData: Comment[] = commentList.map((c) => ({ ...c, createdAt: c.createdAt.toISOString() }));
  const attempt: Attempt | null = attemptRows[0] ? { ...attemptRows[0], createdAt: attemptRows[0].createdAt.toISOString() } : null;
  return { post: serializePublication(raw, commentList.length, stats.value), comments: commentData, attempt, results };
}
export async function getOwnerStats(): Promise<OwnerStats> {
  await requireOwner();
  await settleExpiredAttempts();
  const [readers] = await db.select({ value: count() }).from(users).where(eq(users.isDemo, false));
  const [commentStats] = await db.select({ value: count() }).from(comments);
  const rows = await db.select({ id: quizAttempts.id, publicationId: publications.id, title: publications.title, name: users.name, score: quizAttempts.score,
    total: sql<number>`jsonb_array_length(${publications.questions})`, createdAt: quizAttempts.createdAt, completedAt: quizAttempts.completedAt,
    isDemo: users.isDemo, status: quizAttempts.status, protocolVersion: quizAttempts.protocolVersion,
    correctTimeMs: quizAttempts.correctTimeMs, totalTimeMs: quizAttempts.totalTimeMs, timedOutCount: quizAttempts.timedOutCount })
    .from(quizAttempts).innerJoin(users, eq(users.id, quizAttempts.userId)).innerJoin(publications, eq(publications.id, quizAttempts.publicationId));
  return { readers: readers.value, comments: commentStats.value, attempts: rows.length, recentAttempts: rankQuizAttempts(rows.map((a) => ({ ...a, createdAt: a.createdAt.toISOString(), completedAt: a.completedAt?.toISOString() ?? null }))) };
}
export async function getOwnerAttemptDetail(id: string): Promise<OwnerAttemptDetail | null> {
  await requireOwner();
  if (!/^[a-f0-9-]{36}$/i.test(id)) return null;
  const [existing] = await db.select({ publicationId: quizAttempts.publicationId }).from(quizAttempts).where(eq(quizAttempts.id, id)).limit(1);
  if (!existing) return null;
  await settleExpiredAttempts(existing.publicationId);
  const [row] = await db.select({ attempt: quizAttempts, title: publications.title, questions: publications.questions, name: users.name }).from(quizAttempts).innerJoin(publications, eq(publications.id, quizAttempts.publicationId)).innerJoin(users, eq(users.id, quizAttempts.userId)).where(eq(quizAttempts.id, id)).limit(1);
  if (!row) return null;
  return { id, title: row.title, name: row.name, status: row.attempt.status, score: row.attempt.score,
    correctTimeMs: row.attempt.correctTimeMs, totalTimeMs: row.attempt.totalTimeMs, protocolVersion: row.attempt.protocolVersion,
    questions: (row.questions ?? []).map((q, i) => {
      const selected = row.attempt.answers[i];
      return { ...q, selectedAnswer: selected ?? null, elapsedMs: row.attempt.answerTimesMs[i] ?? null,
        outcome: selected === undefined ? "pending" : selected === -1 ? "timeout" : selected === q.correctAnswer ? "correct" : "incorrect" };
    }) };
}
