import { randomUUID } from "node:crypto";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { publications, quizAttempts, type QuizQuestion } from "@/db/schema";
import { QUESTION_TIME_MS, TIMED_QUIZ_VERSION } from "@/lib/quiz-rules";
import type { QuizSnapshot } from "@/lib/types";

type Transaction = Parameters<Parameters<typeof db.transaction>[0]>[0];
export type StoredAttempt = typeof quizAttempts.$inferSelect;
export type QuizCommand = { type: "read" | "start" } | { type: "answer"; index: number; token: string; answer: number | null };
export class QuizError extends Error {}

export async function databaseTime(tx: Transaction) {
  const result = await tx.execute<{ now: number }>(sql`select floor(extract(epoch from clock_timestamp()) * 1000)::float8 as now`);
  return result.rows[0].now;
}

function recordAnswer(attempt: StoredAttempt, questions: QuizQuestion[], answer: number, elapsedMs: number, at: number) {
  const correct = answer >= 0 && questions[attempt.currentIndex].correctAnswer === answer;
  attempt.answers.push(answer);
  attempt.answerTimesMs.push(elapsedMs);
  attempt.score += correct ? 1 : 0;
  attempt.correctTimeMs = (attempt.correctTimeMs ?? 0) + (correct ? elapsedMs : 0);
  attempt.totalTimeMs = (attempt.totalTimeMs ?? 0) + elapsedMs;
  if (answer === -1) attempt.timedOutCount++;
  attempt.currentIndex++;
  attempt.questionToken = randomUUID();
  if (attempt.currentIndex === questions.length) {
    attempt.status = "completed";
    attempt.completedAt = new Date(at);
    attempt.questionStartedAt = null;
  } else attempt.questionStartedAt = new Date(at);
}

// A closed tab does not pause the attempt. Successive deadlines are derived
// from the previous deadline, not from the next HTTP request.
export function advanceExpiredQuestions(attempt: StoredAttempt, questions: QuizQuestion[], now: number) {
  let changed = false;
  if (attempt.protocolVersion !== TIMED_QUIZ_VERSION) return changed;
  while (attempt.status === "in_progress" && attempt.questionStartedAt) {
    const deadline = attempt.questionStartedAt.getTime() + QUESTION_TIME_MS;
    if (now < deadline) break;
    recordAnswer(attempt, questions, -1, QUESTION_TIME_MS, deadline);
    changed = true;
  }
  return changed;
}

async function persistAttempt(tx: Transaction, attempt: StoredAttempt) {
  await tx.update(quizAttempts).set({ answers: attempt.answers, score: attempt.score, status: attempt.status,
    currentIndex: attempt.currentIndex, questionStartedAt: attempt.questionStartedAt, questionToken: attempt.questionToken,
    answerTimesMs: attempt.answerTimesMs, correctTimeMs: attempt.correctTimeMs, totalTimeMs: attempt.totalTimeMs,
    timedOutCount: attempt.timedOutCount, completedAt: attempt.completedAt }).where(eq(quizAttempts.id, attempt.id));
}
function snapshot(attempt: StoredAttempt | null, questions: QuizQuestion[], closed: boolean, now: number, notice?: string): QuizSnapshot {
  if (!attempt) return { status: closed ? "closed" : "ready", total: questions.length, index: 0, serverNowMs: now, deadlineMs: null, questionToken: null, question: null };
  const running = attempt.status === "in_progress" && !closed;
  const current = running ? questions[attempt.currentIndex] : null;
  return { status: attempt.status === "completed" ? "completed" : closed ? "closed" : "in_progress", total: questions.length,
    index: attempt.status === "completed" ? questions.length : attempt.currentIndex, serverNowMs: now,
    deadlineMs: running && attempt.questionStartedAt ? attempt.questionStartedAt.getTime() + QUESTION_TIME_MS : null,
    questionToken: running ? attempt.questionToken : null,
    question: current ? { question: current.question, options: current.options } : null,
    ...(notice ? { notice } : {}) };
}

export async function executeQuiz(publicationId: string, userId: string, command: QuizCommand): Promise<QuizSnapshot> {
  return db.transaction(async (tx) => {
    // Consistent post -> attempt lock order also serializes editing/publication.
    const [post] = await tx.select().from(publications).where(and(eq(publications.id, publicationId), eq(publications.kind, "quiz"), eq(publications.published, true))).for("update");
    if (!post?.questions?.length) throw new QuizError("Ce quiz n’est pas disponible.");
    let [attempt] = await tx.select().from(quizAttempts).where(and(eq(quizAttempts.publicationId, publicationId), eq(quizAttempts.userId, userId))).for("update");
    let now = await databaseTime(tx);
    if (!attempt) {
      if (command.type === "read" || post.resultsPublished) return snapshot(null, post.questions, post.resultsPublished, now);
      if (command.type !== "start") throw new QuizError("Commencez le quiz avant de répondre.");
      [attempt] = await tx.insert(quizAttempts).values({ publicationId, userId, protocolVersion: TIMED_QUIZ_VERSION,
        status: "in_progress", currentIndex: 0, questionStartedAt: new Date(now), questionToken: randomUUID(),
        answers: [], answerTimesMs: [], score: 0, correctTimeMs: 0, totalTimeMs: 0, createdAt: new Date(now) }).returning();
    }
    let changed = advanceExpiredQuestions(attempt, post.questions, now);
    let notice: string | undefined;
    if (command.type === "answer" && attempt.status === "in_progress" && !post.resultsPublished) {
      if (command.index !== attempt.currentIndex || command.token !== attempt.questionToken) {
        notice = "La question précédente est terminée. Vous êtes synchronisé avec la question en cours.";
      } else if (command.answer !== null) {
        const options = post.questions[attempt.currentIndex].options;
        if (!Number.isInteger(command.answer) || command.answer < 0 || command.answer >= options.length) throw new QuizError("Choisissez l’une des réponses proposées.");
        const elapsed = Math.max(0, now - attempt.questionStartedAt!.getTime());
        recordAnswer(attempt, post.questions, command.answer, elapsed, now);
        changed = true;
      }
      // A null answer before the deadline is a synchronization request, not a skip.
    }
    if (changed) await persistAttempt(tx, attempt);
    now = await databaseTime(tx);
    return snapshot(attempt, post.questions, post.resultsPublished, now, notice);
  });
}

// Called by private reports and result publication. No background process is
// required: elapsed deadlines are settled transactionally on the next read.
export async function settleQuizInTransaction(tx: Transaction, post: typeof publications.$inferSelect, now: number) {
  if (post.kind !== "quiz" || !post.questions) return 0;
  const active = await tx.select().from(quizAttempts).where(and(eq(quizAttempts.publicationId, post.id), eq(quizAttempts.status, "in_progress"))).for("update");
  let stillRunning = 0;
  for (const attempt of active) {
    if (advanceExpiredQuestions(attempt, post.questions, now)) await persistAttempt(tx, attempt);
    if (attempt.status === "in_progress") stillRunning++;
  }
  return stillRunning;
}
export async function settleExpiredAttempts(publicationId?: string) {
  const quizzes = await db.select({ id: publications.id }).from(publications).where(and(eq(publications.kind, "quiz"), publicationId ? eq(publications.id, publicationId) : undefined));
  for (const quiz of quizzes) await db.transaction(async (tx) => {
    const [post] = await tx.select().from(publications).where(eq(publications.id, quiz.id)).for("update");
    if (post) await settleQuizInTransaction(tx, post, await databaseTime(tx));
  });
}
