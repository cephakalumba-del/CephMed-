import { cookies } from "next/headers";
import { createHash, randomBytes } from "node:crypto";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { isOwnerIdentity } from "@/lib/owner";
import type { Reader } from "@/lib/types";

export const googleConfigured = () => Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET);
const hash = (value: string) => createHash("sha256").update(value).digest("hex");

export async function getReader(): Promise<Reader | null> {
  const token = (await cookies()).get("cephmed_session")?.value;
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;
  const [row] = await db.select({ id: users.id, name: users.name, email: users.email, avatar: users.avatar,
    isDemo: users.isDemo, googleId: users.googleId, ownerAuthenticated: sessions.ownerAuthenticated })
    .from(sessions).innerJoin(users, eq(sessions.userId, users.id))
    .where(and(eq(sessions.tokenHash, hash(token)), gt(sessions.expiresAt, new Date()))).limit(1);
  if (!row) return null;
  const isOwner = row.ownerAuthenticated && await isOwnerIdentity(row);
  return { id: row.id, name: row.name, email: row.email, avatar: row.avatar, isDemo: row.isDemo, isOwner };
}
export async function createSession(userId: string) {
  const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!user) throw new Error("Compte introuvable.");
  const ownerAuthenticated = await isOwnerIdentity(user);
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + 1000 * 60 * 60 * (ownerAuthenticated ? 8 : 24 * 14));
  const jar = await cookies();
  const previous = jar.get("cephmed_session")?.value;
  await db.transaction(async (tx) => {
    if (previous) await tx.delete(sessions).where(eq(sessions.tokenHash, hash(previous)));
    await tx.insert(sessions).values({ tokenHash: hash(token), userId, expiresAt, ownerAuthenticated });
  });
  jar.set("cephmed_session", token, { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", expires: expiresAt });
}
export async function destroySession() {
  const jar = await cookies();
  const token = jar.get("cephmed_session")?.value;
  if (token) await db.delete(sessions).where(eq(sessions.tokenHash, hash(token)));
  jar.delete("cephmed_session");
}
export async function requireReader() {
  const reader = await getReader();
  if (!reader) throw new Error("Connectez-vous pour participer.");
  return reader;
}
export async function requireOwner() {
  const reader = await getReader();
  if (!reader?.isOwner) throw new Error("Accès non autorisé.");
  return reader;
}
