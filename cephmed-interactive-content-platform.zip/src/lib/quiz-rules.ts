export const QUESTION_TIME_MS = 20_000;
export const TIMED_QUIZ_VERSION = 2;

export const TIMED_QUIZ_RULES = "Chaque question apparaît dans l’ordre et dispose de 20 secondes. Un clic enregistre définitivement votre réponse et ouvre la suivante. Sans réponse dans le délai, la question est comptée sans réponse et passe automatiquement. Aucun retour en arrière n’est possible, même après rechargement.\n\nLa correction est automatique et consultable uniquement par le propriétaire. Le classement privilégie le nombre de bonnes réponses, puis le temps cumulé sur ces bonnes réponses (le plus court d’abord). Les égalités exactes restent ex æquo. Le propriétaire peut publier le classement final, sans dévoiler les corrections détaillées.";

export function formatQuizTime(ms: number | null | undefined) {
  return ms === null || ms === undefined ? "—" : `${(ms / 1000).toLocaleString("fr-FR", { minimumFractionDigits: 3, maximumFractionDigits: 3 })} s`;
}
export type Rankable = { id: string; publicationId: string; status: string; protocolVersion: number; score: number; correctTimeMs: number | null; isDemo: boolean; createdAt: string };
export function rankQuizAttempts<T extends Rankable>(attempts: T[]): (T & { rank: number | null })[] {
  const sorted = [...attempts].sort((a, b) => a.publicationId.localeCompare(b.publicationId) || b.score - a.score || (a.correctTimeMs ?? Infinity) - (b.correctTimeMs ?? Infinity) || a.createdAt.localeCompare(b.createdAt) || a.id.localeCompare(b.id));
  const groups = new Map<string, { position: number; rank: number; score: number; time: number | null }>();
  return sorted.map((attempt) => {
    if (attempt.status !== "completed" || attempt.isDemo || attempt.protocolVersion !== TIMED_QUIZ_VERSION || attempt.correctTimeMs === null) return { ...attempt, rank: null };
    const previous = groups.get(attempt.publicationId);
    const position = (previous?.position ?? 0) + 1;
    const rank = previous && previous.score === attempt.score && previous.time === attempt.correctTimeMs ? previous.rank : position;
    groups.set(attempt.publicationId, { position, rank, score: attempt.score, time: attempt.correctTimeMs });
    return { ...attempt, rank };
  });
}
