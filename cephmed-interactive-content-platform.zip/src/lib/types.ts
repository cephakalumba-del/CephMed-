import type { PublicationKind, QuizQuestion } from "@/db/schema";

export type Reader = { id: string; name: string; email: string; avatar: string | null; isDemo: boolean; isOwner: boolean };
export type PublicQuestion = Pick<QuizQuestion, "question" | "options">;
export type Publication = {
  id: string; kind: PublicationKind; title: string; excerpt: string; content: string;
  topic: string; cover: string | null; readingTime: number; published: boolean;
  resultsPublished: boolean;
  // Only the owner's studio receives this field. Readers get one question via the timed API.
  questions: QuizQuestion[] | null; questionCount: number; bookAuthor: string | null;
  resourceUrl: string | null; createdAt: string; commentCount: number; participantCount: number;
};
export type Comment = { id: string; body: string; createdAt: string; name: string; avatar: string | null; userId: string; isDemo: boolean };
export type Attempt = { id: string; createdAt: string; status: "in_progress" | "completed"; protocolVersion: number };
export type Result = { name: string; score: number; createdAt: string; rank: number; correctTimeMs: number };
export type ActionResult = { success: boolean; error?: string };
export type QuizSnapshot = {
  status: "ready" | "in_progress" | "completed" | "closed";
  total: number;
  index: number;
  serverNowMs: number;
  deadlineMs: number | null;
  questionToken: string | null;
  question: PublicQuestion | null;
  notice?: string;
};
export type OwnerAttemptSummary = {
  id: string; publicationId: string; title: string; name: string; score: number;
  total: number; createdAt: string; completedAt: string | null; isDemo: boolean;
  status: "in_progress" | "completed"; protocolVersion: number;
  correctTimeMs: number | null; totalTimeMs: number | null; timedOutCount: number; rank: number | null;
};
export type OwnerStats = { readers: number; comments: number; attempts: number; recentAttempts: OwnerAttemptSummary[] };
export type OwnerAttemptDetail = {
  id: string; title: string; name: string; status: "in_progress" | "completed";
  score: number; correctTimeMs: number | null; totalTimeMs: number | null; protocolVersion: number;
  questions: (QuizQuestion & { selectedAnswer: number | null; elapsedMs: number | null; outcome: "correct" | "incorrect" | "timeout" | "pending" })[];
};
