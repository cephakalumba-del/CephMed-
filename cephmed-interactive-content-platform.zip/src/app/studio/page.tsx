import { notFound } from "next/navigation";
import { getReader } from "@/lib/auth";
import { getOwnerStats, getPublications } from "@/lib/content";
import { Studio } from "@/components/studio";
export const dynamic = "force-dynamic";
export const metadata = { title: "Espace privé", robots: { index: false, follow: false, nocache: true } };
export default async function StudioPage() {
  const reader = await getReader();
  if (!reader?.isOwner) notFound();
  const [posts, stats] = await Promise.all([getPublications(true), getOwnerStats()]);
  return <Studio posts={posts} stats={stats}/>;
}
