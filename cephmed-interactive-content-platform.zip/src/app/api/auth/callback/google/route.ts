import { NextRequest, NextResponse } from "next/server";
import { createRemoteJWKSet, jwtVerify } from "jose";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, googleConfigured } from "@/lib/auth";
import { bindVerifiedOwner } from "@/lib/owner";
import { getOrigin } from "@/lib/origin";

const jwks = createRemoteJWKSet(new URL("https://www.googleapis.com/oauth2/v3/certs"));
export async function GET(request: NextRequest) {
  const origin = getOrigin(request);
  const code = request.nextUrl.searchParams.get("code");
  const state = request.nextUrl.searchParams.get("state");
  const expected = request.cookies.get("cephmed_oauth_state")?.value;
  const verifier = request.cookies.get("cephmed_oauth_verifier")?.value;
  let destination = "/?auth=error";
  try {
    if (!googleConfigured() || !code || !state || !expected || state !== expected || !verifier) throw new Error("Invalid authentication state");
    const tokenResponse = await fetch("https://oauth2.googleapis.com/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ code, client_id: process.env.GOOGLE_CLIENT_ID!, client_secret: process.env.GOOGLE_CLIENT_SECRET!, redirect_uri: `${origin}/api/auth/callback/google`, grant_type: "authorization_code", code_verifier: verifier }), cache: "no-store", signal: AbortSignal.timeout(15000) });
    if (!tokenResponse.ok) throw new Error("Token exchange failed");
    const tokens = await tokenResponse.json();
    const { payload } = await jwtVerify(tokens.id_token, jwks, { issuer: ["https://accounts.google.com", "accounts.google.com"], audience: process.env.GOOGLE_CLIENT_ID! });
    if (payload.nonce !== state || typeof payload.sub !== "string" || typeof payload.email !== "string" || payload.email_verified !== true) throw new Error("Unverified identity");
    const email = payload.email.toLowerCase();
    const name = typeof payload.name === "string" ? payload.name.slice(0, 100) : email.split("@")[0];
    const avatar = typeof payload.picture === "string" && payload.picture.startsWith("https://") ? payload.picture : null;
    const [user] = await db.insert(users).values({ googleId: payload.sub, email, name, avatar, isDemo: false }).onConflictDoUpdate({ target: users.googleId, set: { email, name, avatar } }).returning();
    await bindVerifiedOwner(user);
    await createSession(user.id);
    const back = request.cookies.get("cephmed_oauth_return")?.value || "/";
    destination = /^\/(?!\/)/.test(back) && !/[\\\r\n]/.test(back) ? back : "/";
  } catch (error) {
    console.error("Google sign-in failed:", error instanceof Error ? error.message : "Unknown error");
  }
  const response = NextResponse.redirect(new URL(destination, origin));
  for (const name of ["cephmed_oauth_state", "cephmed_oauth_verifier", "cephmed_oauth_return"]) response.cookies.delete(name);
  return response;
}
