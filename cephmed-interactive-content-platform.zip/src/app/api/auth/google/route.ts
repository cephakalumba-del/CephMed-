import { NextRequest, NextResponse } from "next/server";
import { randomBytes, createHash } from "node:crypto";
import { googleConfigured } from "@/lib/auth";
import { getOrigin } from "@/lib/origin";
export async function GET(request: NextRequest) {
  const origin = getOrigin(request);
  if (!googleConfigured()) return NextResponse.redirect(new URL("/?auth=unavailable", origin));
  const state = randomBytes(32).toString("hex");
  const verifier = randomBytes(48).toString("base64url");
  const requested = request.nextUrl.searchParams.get("returnTo") || "/";
  const returnTo = /^\/(?!\/)/.test(requested) && !/[\\\r\n]/.test(requested) ? requested : "/";
  const params = new URLSearchParams({ client_id: process.env.GOOGLE_CLIENT_ID!, redirect_uri: `${origin}/api/auth/callback/google`, response_type: "code", scope: "openid email profile", state, nonce: state, code_challenge: createHash("sha256").update(verifier).digest("base64url"), code_challenge_method: "S256", prompt: "select_account", hl: "fr" });
  const response = NextResponse.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params}`);
  const options = { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax" as const, path: "/", maxAge: 600 };
  response.cookies.set("cephmed_oauth_state", state, options);
  response.cookies.set("cephmed_oauth_verifier", verifier, options);
  response.cookies.set("cephmed_oauth_return", returnTo, options);
  return response;
}
