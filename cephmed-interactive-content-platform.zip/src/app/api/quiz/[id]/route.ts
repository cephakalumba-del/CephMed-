import { NextRequest, NextResponse } from "next/server";
import { getReader } from "@/lib/auth";
import { getOrigin } from "@/lib/origin";
import { executeQuiz, QuizError, type QuizCommand } from "@/lib/quiz-engine";

export const dynamic = "force-dynamic";
const headers = { "Cache-Control": "private, no-store, max-age=0", Vary: "Cookie", "X-Content-Type-Options": "nosniff" };
const response = (body: unknown, status = 200) => NextResponse.json(body, { status, headers });

async function handle(request: NextRequest, id: string, command: QuizCommand) {
  const reader = await getReader();
  if (!reader) return response({ error: "Connectez-vous pour participer au quiz." }, 401);
  if (reader.isOwner) return response({ error: "Consultez le quiz dans votre studio. Le propriétaire ne participe pas au classement." }, 403);
  if (!id || id.length > 180) return response({ error: "Quiz introuvable." }, 404);
  try { return response(await executeQuiz(id, reader.id, command)); }
  catch (error) {
    if (error instanceof QuizError) return response({ error: error.message }, 400);
    console.error("Timed quiz request failed", error instanceof Error ? error.name : "Unknown error");
    return response({ error: "La synchronisation a échoué. Réessayez ; le chronomètre serveur continue." }, 503);
  }
}
export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return handle(request, id, { type: "read" });
}
export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  // Cookie-authenticated mutations must originate from the site itself.
  const origin = request.headers.get("origin");
  if (!origin || origin !== new URL(getOrigin(request)).origin) return response({ error: "Origine de requête refusée." }, 403);
  if (!request.headers.get("content-type")?.startsWith("application/json")) return response({ error: "Format de requête invalide." }, 415);
  const { id } = await params;
  try {
    const text = await request.text();
    if (text.length > 4096) return response({ error: "Requête trop volumineuse." }, 413);
    const body = JSON.parse(text);
    if (body?.action === "start") return handle(request, id, { type: "start" });
    if (body?.action !== "answer" || !Number.isInteger(body.questionIndex) || body.questionIndex < 0 || body.questionIndex > 29 || typeof body.questionToken !== "string" || !/^[a-f0-9-]{36}$/i.test(body.questionToken) || (body.answer !== null && (!Number.isInteger(body.answer) || body.answer < 0 || body.answer > 5))) return response({ error: "Réponse invalide." }, 400);
    return handle(request, id, { type: "answer", index: body.questionIndex, token: body.questionToken, answer: body.answer });
  } catch { return response({ error: "Requête invalide." }, 400); }
}
