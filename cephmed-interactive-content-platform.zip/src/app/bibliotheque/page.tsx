import { ExplorePage } from "@/components/explore-page";
export const metadata = { title: "La bibliothèque" };
export default function LibraryPage() { return <ExplorePage kind="livre"/>; }
