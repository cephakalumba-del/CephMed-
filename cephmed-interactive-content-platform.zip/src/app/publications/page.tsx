import { ExplorePage } from "@/components/explore-page";
export const metadata = { title: "Toutes les publications" };
export default async function PublicationsPage({ searchParams }: { searchParams: Promise<{ recherche?: string }> }) {
  const params = await searchParams;
  return <ExplorePage search={typeof params.recherche === "string" ? params.recherche : ""}/>;
}
