import { notFound } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { publications } from "@/db/schema";
import { getReader } from "@/lib/auth";
import { getPublicationDetail, getSavedIds } from "@/lib/content";
import { PublicationDetail } from "@/components/publication-detail";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [post] = await db.select({ title: publications.title, excerpt: publications.excerpt }).from(publications).where(and(eq(publications.id, slug), eq(publications.published, true))).limit(1);
  return { title: post?.title || "Une découverte vous attend", description: post?.excerpt };
}
export default async function PublicationPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const reader = await getReader();
  const [detail, savedIds] = await Promise.all([getPublicationDetail(slug, reader), getSavedIds(reader)]);
  if (!detail) notFound();
  return <PublicationDetail {...detail} saved={savedIds.includes(slug)}/>;
}
