"use client";
import { RotateCcw, Sprout } from "lucide-react";
export default function ErrorPage({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return <main className="error-page"><Sprout size={43} strokeWidth={1.2}/><h1>Une petite pause imprévue.</h1><p>La page n’a pas pu être chargée. Vos découvertes n’ont pas disparu : réessayons dans un instant.</p><button className="btn btn-primary" onClick={reset}>Réessayer <RotateCcw size={15}/></button></main>;
}
