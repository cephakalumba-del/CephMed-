"use server";

import { revalidatePath } from "next/cache";
import { randomUUID } from "node:crypto";
import { and, eq, count, gt } from "drizzle-orm";
import { db } from "@/db";
import { bookmarks, comments, publications, quizAttempts, subscriptions, users, type PublicationKind, type QuizQuestion } from "@/db/schema";
import { createSession, destroySession, googleConfigured, requireOwner, requireReader } from "@/lib/auth";
import { databaseTime, settleQuizInTransaction } from "@/lib/quiz-engine";
import { getOwnerAttemptDetail } from "@/lib/content";

const failure = (error: unknown) => ({ success: false as const, error: error instanceof Error && !error.message.includes("query:") ? error.message : "Une erreur est survenue. Veuillez réessayer." });
function refresh(id?: string) {
  revalidatePath("/", "layout");
  if (id) revalidatePath(`/publications/${id}`);
}
async function readablePost(id: string) {
  const [post] = await db.select().from(publications).where(and(eq(publications.id, id), eq(publications.published, true))).limit(1);
  if (!post) throw new Error("Cette publication n’est plus disponible.");
  return post;
}
export async function signInDemo(name: string) {
  try {
    if (googleConfigured() || process.env.ALLOW_DEMO_LOGIN === "false") throw new Error("Utilisez la connexion Google pour vous identifier.");
    const safeName = typeof name === "string" ? name.trim().slice(0, 50) : "";
    if (safeName.length < 2) throw new Error("Indiquez un prénom d’au moins 2 caractères.");
    const [reader] = await db.insert(users).values({ name: safeName, email: `demo-${randomUUID()}@cephmed.invalid`, isDemo: true }).returning();
    await createSession(reader.id);
    refresh();
    return { success: true as const };
  } catch (error) { return failure(error); }
}
export async function signOut() { await destroySession(); refresh(); return { success: true as const }; }
export async function addComment(publicationId: string, body: string) {
  try {
    const reader = await requireReader();
    await readablePost(publicationId);
    const clean = typeof body === "string" ? body.trim() : "";
    if (clean.length < 3 || clean.length > 2000) throw new Error("Votre commentaire doit contenir entre 3 et 2 000 caractères.");
    const [recent] = await db.select({ value: count() }).from(comments).where(and(eq(comments.userId, reader.id), gt(comments.createdAt, new Date(Date.now() - 60000))));
    if (recent.value >= 5) throw new Error("Prenez un petit instant avant de publier un autre commentaire.");
    await db.insert(comments).values({ publicationId, userId: reader.id, body: clean });
    refresh(publicationId);
    return { success: true as const };
  } catch (error) { return failure(error); }
}
export async function deleteComment(id: string) {
  try {
    const reader = await requireReader();
    await db.delete(comments).where(and(eq(comments.id, id), reader.isOwner ? undefined : eq(comments.userId, reader.id)));
    refresh();
    return { success: true as const };
  } catch (error) { return failure(error); }
}
export async function setBookmark(publicationId: string, saved: boolean) {
  try {
    const reader = await requireReader();
    await readablePost(publicationId);
    if (saved) await db.insert(bookmarks).values({ userId: reader.id, publicationId }).onConflictDoNothing();
    else await db.delete(bookmarks).where(and(eq(bookmarks.publicationId, publicationId), eq(bookmarks.userId, reader.id)));
    refresh();
    return { success: true as const };
  } catch (error) { return failure(error); }
}
export async function subscribe(email: string, consent: boolean) {
  try {
    if (!consent) throw new Error("Veuillez accepter de recevoir les nouvelles de CephMed.");
    const clean = typeof email === "string" ? email.trim().toLowerCase() : "";
    if (clean.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(clean)) throw new Error("Indiquez une adresse e-mail valide.");
    await db.insert(subscriptions).values({ email: clean }).onConflictDoNothing();
    return { success: true as const };
  } catch (error) { return failure(error); }
}

export type PublicationInput = { id?: string; kind: PublicationKind; title: string; excerpt: string; content: string; topic: string; readingTime: number; published: boolean; cover?: string; bookAuthor?: string; resourceUrl?: string; questions?: QuizQuestion[] };
export async function savePublication(input: PublicationInput) {
  try {
    await requireOwner();
    if (!["conseil", "livre", "quiz"].includes(input.kind)) throw new Error("Choisissez un type de publication valide.");
    if (typeof input.title !== "string" || input.title.trim().length < 5 || input.title.length > 180) throw new Error("Le titre doit contenir entre 5 et 180 caractères.");
    if (!input.excerpt?.trim() || input.excerpt.length > 400 || !input.content?.trim() || input.content.length > 60000) throw new Error("Ajoutez un résumé (400 caractères maximum) et un contenu (60 000 caractères maximum).");
    if (!input.topic?.trim() || input.topic.length > 80) throw new Error("Ajoutez une thématique de 80 caractères maximum.");
    if (!Number.isInteger(input.readingTime) || input.readingTime < 1 || input.readingTime > 120) throw new Error("La durée doit être comprise entre 1 et 120 minutes.");
    if (input.resourceUrl && !/^https:\/\//.test(input.resourceUrl)) throw new Error("Le lien du livre doit commencer par https://.");
    if (input.cover && !/^https:\/\//.test(input.cover) && !/^\/images\/[\w.-]+$/.test(input.cover)) throw new Error("Utilisez une image HTTPS ou une image locale de /images/.");
    if (input.kind === "quiz") {
      if (!Array.isArray(input.questions) || input.questions.length < 1 || input.questions.length > 30) throw new Error("Un quiz doit contenir entre 1 et 30 questions.");
      for (const q of input.questions) {
        if (!q.question?.trim() || q.question.length > 500 || !Array.isArray(q.options) || q.options.length < 2 || q.options.length > 6 || q.options.some((o) => typeof o !== "string" || !o.trim() || o.length > 300) || !Number.isInteger(q.correctAnswer) || q.correctAnswer < 0 || q.correctAnswer >= q.options.length || typeof q.explanation !== "string" || q.explanation.length > 2000) throw new Error("Vérifiez les questions : au moins deux réponses et une bonne réponse sont nécessaires.");
      }
    }
    const id = input.id || `${input.title.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 75)}-${randomUUID().slice(0, 6)}`;
    await db.transaction(async (tx) => {
      if (input.id) {
        const [existing] = await tx.select().from(publications).where(eq(publications.id, id)).for("update");
        if (!existing) throw new Error("Publication introuvable.");
        const [attempts] = await tx.select({ value: count() }).from(quizAttempts).where(eq(quizAttempts.publicationId, id));
        if ((attempts.value > 0 || existing.resultsPublished) && (input.kind !== existing.kind || JSON.stringify(input.questions?.map(({ question, options, correctAnswer, explanation }) => ({ question, options, correctAnswer, explanation }))) !== JSON.stringify(existing.questions?.map(({ question, options, correctAnswer, explanation }) => ({ question, options, correctAnswer, explanation }))))) throw new Error("Les questions d’un quiz ayant reçu des participations ou déjà clôturé ne peuvent plus être modifiées.");
      }
      const values = { kind: input.kind, title: input.title.trim(), excerpt: input.excerpt.trim(), content: input.content.trim(), topic: input.topic.trim(), readingTime: input.kind === "quiz" ? Math.max(1, Math.ceil(input.questions!.length / 3)) : input.readingTime, published: Boolean(input.published), cover: input.cover?.trim() || null, bookAuthor: input.bookAuthor?.trim().slice(0, 150) || null, resourceUrl: input.resourceUrl?.trim() || null, questions: input.kind === "quiz" ? input.questions! : null };
      if (input.id) await tx.update(publications).set(values).where(eq(publications.id, id));
      else await tx.insert(publications).values({ id, ...values });
    });
    refresh(id);
    return { success: true as const, id };
  } catch (error) { return failure(error); }
}
export async function publishQuizResults(id: string) {
  try {
    await requireOwner();
    await db.transaction(async (tx) => {
      const [post] = await tx.select().from(publications).where(and(eq(publications.id, id), eq(publications.kind, "quiz"))).for("update");
      if (!post) throw new Error("Quiz introuvable.");
      const active = await settleQuizInTransaction(tx, post, await databaseTime(tx));
      if (active) throw new Error(`${active} participation(s) sont encore en cours. Attendez leur fin avant de publier le classement.`);
      await tx.update(publications).set({ resultsPublished: true }).where(eq(publications.id, id));
    });
    refresh(id);
    return { success: true as const };
  } catch (error) { return failure(error); }
}
export async function getAttemptCorrection(id: string) {
  try {
    await requireOwner();
    const detail = await getOwnerAttemptDetail(id);
    if (!detail) throw new Error("Participation introuvable.");
    return { success: true as const, detail };
  } catch (error) { return failure(error); }
}
export async function deletePublication(id: string) {
  try {
    await requireOwner();
    await db.delete(publications).where(eq(publications.id, id));
    refresh();
    return { success: true as const };
  } catch (error) { return failure(error); }
}
