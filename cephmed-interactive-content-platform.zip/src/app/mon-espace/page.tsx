import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { publications, quizAttempts } from "@/db/schema";
import { getReader } from "@/lib/auth";
import { getPublications, getSavedIds } from "@/lib/content";
import { executeQuiz } from "@/lib/quiz-engine";
import { AccessGate } from "@/components/access-gate";
import { MemberDashboard, type ReaderAttempt } from "@/components/member-dashboard";
export const metadata = { title: "Mon espace lecteur", robots: { index: false, follow: false } };
export default async function MemberPage() {
  const reader = await getReader();
  if (!reader) return <AccessGate/>;
  const active = await db.select({ id: publications.id }).from(quizAttempts).innerJoin(publications, eq(publications.id, quizAttempts.publicationId)).where(and(eq(quizAttempts.userId, reader.id), eq(quizAttempts.status, "in_progress"), eq(publications.published, true)));
  for (const quiz of active) await executeQuiz(quiz.id, reader.id, { type: "read" });
  const [posts, savedIds, attemptRows] = await Promise.all([getPublications(), getSavedIds(reader), db.select({ id: quizAttempts.id, publicationId: publications.id, title: publications.title, createdAt: quizAttempts.createdAt, status: quizAttempts.status, resultsPublished: publications.resultsPublished }).from(quizAttempts).innerJoin(publications, eq(publications.id, quizAttempts.publicationId)).where(and(eq(quizAttempts.userId, reader.id), eq(publications.published, true))).orderBy(desc(quizAttempts.createdAt))]);
  const attempts: ReaderAttempt[] = attemptRows.map((a) => ({ ...a, createdAt: a.createdAt.toISOString() }));
  return <MemberDashboard posts={posts} savedIds={savedIds} attempts={attempts}/>;
}
