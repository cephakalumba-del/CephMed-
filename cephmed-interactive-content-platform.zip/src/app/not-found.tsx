import Link from "next/link";
import { ArrowRight, Compass } from "lucide-react";
export default function NotFound() {
  return <main className="error-page"><Compass size={45} strokeWidth={1.2}/><span className="eyebrow">UNE PETITE PARENTHÈSE DANS L’EXPLORATION</span><h1>Cette page s’est égarée.</h1><p>Elle a peut-être changé d’adresse ou n’est plus disponible. D’autres découvertes vous attendent sur CephMed.</p><Link className="btn btn-primary" href="/publications">Reprendre mon exploration <ArrowRight size={15}/></Link></main>;
}
