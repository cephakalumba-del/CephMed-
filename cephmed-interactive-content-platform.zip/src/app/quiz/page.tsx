import { ExplorePage } from "@/components/explore-page";
export const metadata = { title: "Les quiz" };
export default function QuizPage() { return <ExplorePage kind="quiz"/>; }
