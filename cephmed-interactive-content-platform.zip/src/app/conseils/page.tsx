import { ExplorePage } from "@/components/explore-page";
export const metadata = { title: "Les conseils" };
export default function AdvicePage() { return <ExplorePage kind="conseil"/>; }
