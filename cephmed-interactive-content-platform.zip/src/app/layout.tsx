import type { Metadata } from "next";
import type { ReactNode } from "react";
import { getReader, googleConfigured } from "@/lib/auth";
import { SiteProvider } from "@/components/site-provider";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import "./globals.css";
import "./quiz.css";

export const metadata: Metadata = {
  title: { default: "CephMed — Un peu de savoir. Beaucoup de sens.", template: "%s · CephMed" },
  description: "Des conseils pour mieux vivre, des livres pour s’inspirer et des quiz pour éveiller votre curiosité. Le savoir grandit quand on le partage.",
};
export default async function RootLayout({ children }: { children: ReactNode }) {
  const reader = await getReader();
  const googleAvailable = googleConfigured();
  return <html lang="fr"><body><SiteProvider reader={reader} googleAvailable={googleAvailable} allowDemo={!googleAvailable && process.env.ALLOW_DEMO_LOGIN !== "false"}><a className="skip-link" href="#main-content">Aller au contenu</a><SiteHeader/><div id="main-content">{children}</div><SiteFooter/></SiteProvider></body></html>;
}
