import { pgTable, text, timestamp, uuid, boolean, integer, jsonb, uniqueIndex, primaryKey } from "drizzle-orm/pg-core";

export type PublicationKind = "conseil" | "livre" | "quiz";
export type QuizQuestion = { question: string; options: string[]; correctAnswer: number; explanation: string };

export const users = pgTable("users", {
  id: uuid("id").defaultRandom().primaryKey(),
  googleId: text("google_id").unique(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  avatar: text("avatar"),
  isDemo: boolean("is_demo").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
export const sessions = pgTable("sessions", {
  tokenHash: text("token_hash").primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at").notNull(),
  ownerAuthenticated: boolean("owner_authenticated").notNull().default(false),
});
export const publications = pgTable("publications", {
  id: text("id").primaryKey(),
  kind: text("kind").$type<PublicationKind>().notNull(),
  title: text("title").notNull(),
  excerpt: text("excerpt").notNull(),
  content: text("content").notNull(),
  topic: text("topic").notNull(),
  cover: text("cover"),
  readingTime: integer("reading_time").notNull().default(5),
  published: boolean("published").notNull().default(true),
  resultsPublished: boolean("results_published").notNull().default(false),
  questions: jsonb("questions").$type<QuizQuestion[]>(),
  bookAuthor: text("book_author"),
  resourceUrl: text("resource_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
export const comments = pgTable("comments", {
  id: uuid("id").defaultRandom().primaryKey(),
  publicationId: text("publication_id").notNull().references(() => publications.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  body: text("body").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
export const quizAttempts = pgTable("quiz_attempts", {
  id: uuid("id").defaultRandom().primaryKey(),
  publicationId: text("publication_id").notNull().references(() => publications.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  answers: jsonb("answers").$type<number[]>().notNull(),
  score: integer("score").notNull(),
  // Defaults preserve pre-timer submissions as completed, unranked archives.
  protocolVersion: integer("protocol_version").notNull().default(1),
  status: text("status").$type<"in_progress" | "completed">().notNull().default("completed"),
  currentIndex: integer("current_index").notNull().default(0),
  questionStartedAt: timestamp("question_started_at"),
  questionToken: uuid("question_token").defaultRandom().notNull(),
  answerTimesMs: jsonb("answer_times_ms").$type<number[]>().notNull().default([]),
  correctTimeMs: integer("correct_time_ms"),
  totalTimeMs: integer("total_time_ms"),
  timedOutCount: integer("timed_out_count").notNull().default(0),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (t) => [uniqueIndex("one_attempt_per_reader").on(t.publicationId, t.userId)]);
export const bookmarks = pgTable("bookmarks", {
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  publicationId: text("publication_id").notNull().references(() => publications.id, { onDelete: "cascade" }),
}, (t) => [primaryKey({ columns: [t.userId, t.publicationId] })]);
export const subscriptions = pgTable("subscriptions", {
  email: text("email").primaryKey(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
export const siteSettings = pgTable("site_settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
});
