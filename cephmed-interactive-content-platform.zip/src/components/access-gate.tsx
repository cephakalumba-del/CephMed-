"use client";

import Link from "next/link";
import { ArrowLeft, ArrowRight, Bookmark, ListChecks, MessageCircle } from "lucide-react";
import { useSite } from "@/components/site-provider";
import { GoogleIcon } from "@/components/brand";

export function AccessGate() {
  const { openLogin } = useSite();
  return <main className="gate-page"><div className="gate-card"><div className="gate-icon"><Bookmark size={29} strokeWidth={1.3}/></div><span className="eyebrow">VOTRE PETIT COIN DE CEPHMED</span><h1>Vos découvertes vous attendent.</h1><p>Retrouvez vos lectures favorites et vos participations aux quiz. Un compte Google suffit pour vous sentir chez vous.</p><button className="btn btn-primary" onClick={() => openLogin("Connectez-vous pour retrouver vos favoris et suivre vos participations aux quiz.")}><GoogleIcon/>Me connecter à mon espace<ArrowRight size={14}/></button><div className="gate-features"><span><Bookmark size={13}/> Lectures favorites</span><span><ListChecks size={13}/> Mes participations</span><span><MessageCircle size={13}/> Mes échanges</span></div></div><Link className="gate-back" href="/"><ArrowLeft size={13}/> Revenir aux découvertes</Link></main>;
}
