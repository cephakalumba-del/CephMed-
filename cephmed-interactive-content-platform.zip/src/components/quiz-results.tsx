"use client";

import { useCallback, useRef, useState, useTransition } from "react";
import { CheckCircle2, Clock3, Download, Eye, Loader2, LockKeyhole, ShieldCheck, Timer, Trophy, XCircle } from "lucide-react";
import { getAttemptCorrection } from "@/app/actions";
import { Dialog } from "@/components/dialog";
import { formatQuizTime } from "@/lib/quiz-rules";
import type { OwnerAttemptDetail, OwnerAttemptSummary, Publication } from "@/lib/types";

export function QuizResults({ attempts, posts }: { attempts: OwnerAttemptSummary[]; posts: Publication[] }) {
  const [filter, setFilter] = useState("all");
  const [selected, setSelected] = useState<string | null>(null);
  const [detail, setDetail] = useState<OwnerAttemptDetail | null>(null);
  const [error, setError] = useState("");
  const [pending, startTransition] = useTransition();
  const detailRequest = useRef(0);
  const close = useCallback(() => { detailRequest.current++; setSelected(null); setDetail(null); setError(""); }, []);
  const rows = attempts.filter((attempt) => filter === "all" || attempt.publicationId === filter);
  const open = (id: string) => {
    const requestId = ++detailRequest.current;
    setSelected(id); setDetail(null); setError("");
    startTransition(async () => {
      const result = await getAttemptCorrection(id);
      if (detailRequest.current !== requestId) return;
      if (result.success) setDetail(result.detail); else setError(result.error);
    });
  };
  function exportCsv() {
    const cell = (value: unknown) => { const text = String(value ?? ""); return `"${(/^[=+\-@\t\r]/.test(text) ? "'" : "") + text.replaceAll('"', '""')}"`; };
    const data = [["Quiz", "Rang", "Participant", "Bonnes réponses", "Questions", "Temps des bonnes réponses (ms)", "Temps total (ms)", "Questions expirées", "Statut", "Démonstration", "Version", "Date"], ...rows.map((a) => [a.title, a.rank, a.name, a.score, a.total, a.correctTimeMs, a.totalTimeMs, a.timedOutCount, a.status, a.isDemo ? "Oui" : "Non", a.protocolVersion, new Date(a.createdAt).toLocaleString("fr-FR")])];
    const url = URL.createObjectURL(new Blob(["\ufeff" + data.map((r) => r.map(cell).join(";")).join("\r\n")], { type: "text/csv;charset=utf-8;" }));
    const a = document.createElement("a"); a.href = url; a.download = "cephmed-classement-prive.csv"; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  return <section className="owner-quiz-results"><div className="private-ranking-note"><ShieldCheck size={25} strokeWidth={1.5}/><div><strong>Correction automatique. Visibilité privée.</strong><p>Le serveur corrige chaque réponse et mesure son délai. Vous seul voyez ce détail. Publier un classement ne divulgue jamais les corrections.</p></div><span className="private-pill"><LockKeyhole size={11}/> Vous uniquement</span></div><div className="ranking-method"><span><strong>01</strong> Le plus de bonnes réponses</span><span><strong>02</strong> Le temps cumulé le plus court sur ces réponses</span><small>Les égalités exactes restent ex æquo. Démonstrations et anciennes participations non chronométrées : hors classement.</small></div><div className="studio-table-toolbar ranking-toolbar"><label className="ranking-filter">Afficher<select aria-label="Choisir un quiz" value={filter} onChange={(e) => setFilter(e.target.value)}><option value="all">Tous les quiz</option>{posts.filter((p) => p.kind === "quiz").map((p) => <option key={p.id} value={p.id}>{p.title}</option>)}</select></label><button className="btn btn-outline" disabled={!rows.length} onClick={exportCsv}><Download size={14}/> Exporter ce classement</button></div>{rows.length ? <div className="studio-table-wrap"><table className="studio-table ranking-table"><thead><tr><th>Rang</th><th>Participant / quiz</th><th>Bonnes réponses</th><th>Temps de départage</th><th>État</th><th>Correction privée</th></tr></thead><tbody>{rows.map((a) => <tr key={a.id}><td><span className={`owner-rank ${a.rank === 1 ? "first" : ""}`}>{a.rank === 1 ? <Trophy size={16}/> : a.rank ?? "—"}</span></td><td><strong>{a.name}</strong>{a.isDemo && <span className="demo-badge" style={{ marginLeft: 6 }}>Démo</span>}<small>{a.title}</small></td><td><strong>{a.score} / {a.total}</strong>{a.status === "in_progress" && <small>Provisoire</small>}</td><td className="time-cell">{formatQuizTime(a.correctTimeMs)}<small>{a.timedOutCount} sans réponse</small></td><td><span className={`publication-status ${a.status === "in_progress" ? "draft" : ""}`}>{a.protocolVersion < 2 ? "Archive" : a.status === "in_progress" ? "En cours" : "Corrigé"}</span></td><td><button className="text-button correction-button" onClick={() => open(a.id)} aria-label={`Voir la correction de ${a.name}`}><Eye size={14}/> Voir le détail</button></td></tr>)}</tbody></table></div> : <div className="empty-state"><Timer size={34} strokeWidth={1.2}/><h3>Les réponses apparaîtront ici.</h3><p>Dès le début d’une participation, vous pouvez suivre la correction. Le classement devient définitif à la fin du quiz.</p></div>}
    {selected && <Dialog title="Correction privée d’une participation" onClose={close} wide><div className="correction-detail"><span className="eyebrow"><LockKeyhole size={11}/> CORRECTION PRIVÉE · PROPRIÉTAIRE UNIQUEMENT</span>{pending && !detail ? <div className="empty-state"><Loader2 className="spin" size={28}/><p>Chargement de la correction sécurisée…</p></div> : error ? <p className="form-error" role="alert">{error}</p> : detail && <><h2>{detail.name}</h2><p className="correction-quiz-title">{detail.title}</p><div className="correction-summary"><span><CheckCircle2 size={18}/><strong>{detail.score} / {detail.questions.length}</strong> bonnes réponses</span><span><Timer size={18}/><strong>{formatQuizTime(detail.correctTimeMs)}</strong> temps de départage</span><span><Clock3 size={18}/><strong>{formatQuizTime(detail.totalTimeMs)}</strong> temps total</span></div>{detail.status === "in_progress" && <p className="form-notice">Cette participation est encore en cours. Les réponses non encore données ne sont pas notées.</p>}{detail.protocolVersion < 2 && <p className="form-notice">Archive antérieure au chronomètre : aucun temps n’a été inventé. Cette participation est hors classement chronométré.</p>}{detail.questions.map((q, i) => <article key={i} className={`private-question outcome-${q.outcome}`}><div className="private-question-top"><span>QUESTION {i + 1}</span><span>{q.outcome === "correct" ? <CheckCircle2 size={14}/> : q.outcome === "incorrect" ? <XCircle size={14}/> : <Clock3 size={14}/>} {q.outcome === "correct" ? "Bonne réponse" : q.outcome === "incorrect" ? "Réponse incorrecte" : q.outcome === "timeout" ? "Temps écoulé" : "À venir"} · {formatQuizTime(q.elapsedMs)}</span></div><h3>{q.question}</h3><p className="submitted-answer"><strong>Réponse du participant :</strong> {q.selectedAnswer === null ? "Non encore donnée" : q.selectedAnswer === -1 ? "Aucune — délai de 20 secondes dépassé" : q.options[q.selectedAnswer]}</p><p className="correct-answer"><CheckCircle2 size={14}/><strong>Bonne réponse :</strong> {q.options[q.correctAnswer]}</p><p className="answer-explanation">{q.explanation}</p></article>)}</>}</div></Dialog>}
  </section>;
}
