"use client";

import { useState, useTransition } from "react";
import { ArrowRight, CheckCircle2, Loader2, Mail, Send } from "lucide-react";
import { subscribe } from "@/app/actions";

export function Newsletter() {
  const [email, setEmail] = useState("");
  const [consent, setConsent] = useState(false);
  const [status, setStatus] = useState("");
  const [done, setDone] = useState(false);
  const [pending, startTransition] = useTransition();
  return <section className="newsletter"><div className="newsletter-drawing" aria-hidden="true"><Mail size={42} strokeWidth={1}/><Send size={22} className="letter-send" strokeWidth={1.2}/><span className="letter-dash"/></div><div className="newsletter-copy"><span className="eyebrow">UN PEU DE CEPHMED DANS VOTRE QUOTIDIEN</span><h2>Gardons le fil de la curiosité.</h2><p>De nouvelles idées, de belles lectures. L’essentiel, simplement.</p></div><div className="newsletter-form-area">{done ? <div className="newsletter-success" role="status"><CheckCircle2 size={25}/><div><strong>Vous êtes sur la liste !</strong><p>Votre inscription est enregistrée. Merci de votre curiosité.</p></div></div> : <form onSubmit={(e) => { e.preventDefault(); setStatus(""); startTransition(async () => { const result = await subscribe(email, consent); if (result.success) setDone(true); else setStatus(result.error); }); }}><div className="newsletter-input"><input type="email" aria-label="Votre adresse e-mail" placeholder="Votre adresse e-mail" required maxLength={254} value={email} onChange={(e) => setEmail(e.target.value)}/><button className="btn btn-primary" disabled={pending} aria-label="M’inscrire à la newsletter">{pending ? <Loader2 size={18} className="spin"/> : <ArrowRight size={20}/>}</button></div><label className="consent-label"><input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} required/>J’accepte de recevoir les nouvelles de CephMed.</label>{status && <p className="form-error" role="alert">{status}</p>}<small>Pas de bruit, juste de belles découvertes.</small></form>}</div></section>;
}
