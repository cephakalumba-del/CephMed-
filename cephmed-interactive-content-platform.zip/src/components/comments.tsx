"use client";

import { useCallback, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { ArrowRight, Loader2, MessageCircle, Send, Trash2 } from "lucide-react";
import { addComment, deleteComment } from "@/app/actions";
import { useSite } from "@/components/site-provider";
import { Dialog } from "@/components/dialog";
import type { Comment } from "@/lib/types";

export function Comments({ publicationId, comments }: { publicationId: string; comments: Comment[] }) {
  const { reader, openLogin, notify } = useSite();
  const router = useRouter();
  const [body, setBody] = useState("");
  const [error, setError] = useState("");
  const [pending, startTransition] = useTransition();
  const [deleting, setDeleting] = useState<string | null>(null);
  const closeDelete = useCallback(() => setDeleting(null), []);
  return <section className="comments-section" id="commentaires"><div className="comments-heading"><h2>Et vous, qu’en pensez-vous ?</h2><span className="count-pill">{comments.length}</span></div><p className="comments-description">Un point de vue, une expérience, une question… La conversation est ouverte.</p>
    {reader ? <form className="comment-form" onSubmit={(e) => { e.preventDefault(); setError(""); startTransition(async () => { const result = await addComment(publicationId, body); if (result.success) { setBody(""); router.refresh(); notify("Votre commentaire est publié. Merci pour ce partage !"); } else setError(result.error); }); }}><div className="comment-form-header"><span className="avatar">{reader.avatar ? <img src={reader.avatar} referrerPolicy="no-referrer" alt=""/> : reader.name.charAt(0).toUpperCase()}</span><strong>{reader.name}</strong>{reader.isDemo && <span className="demo-badge">Démo</span>}</div><textarea value={body} onChange={(e) => setBody(e.target.value)} minLength={3} maxLength={2000} required disabled={pending} aria-label="Votre commentaire" placeholder="Partagez votre point de vue avec bienveillance…"/><div className="comment-form-footer"><small>Votre nom et votre commentaire seront publics. {body.length}/2000</small><button className="btn btn-primary" type="submit" disabled={pending || body.trim().length < 3}>{pending ? <Loader2 className="spin" size={13}/> : <Send size={13}/>} Publier mon avis</button></div>{error && <p className="form-error" role="alert">{error}</p>}</form> : <div className="comment-login"><p>Les bonnes conversations commencent par une rencontre.</p><button className="btn btn-primary" onClick={() => openLogin("Connectez-vous pour prendre part à la conversation. Votre nom sera affiché avec votre commentaire.")}>Me connecter pour commenter <ArrowRight size={14}/></button></div>}
    <div className="comment-list">{comments.length ? comments.map((comment) => <article className="comment" key={comment.id}><span className="avatar">{comment.avatar ? <img src={comment.avatar} alt="" referrerPolicy="no-referrer"/> : comment.name.charAt(0).toUpperCase()}</span><div className="comment-content"><div className="comment-meta"><strong>{comment.name}</strong>{comment.isDemo && <span className="demo-badge">Démo</span>}<time dateTime={comment.createdAt}>{new Date(comment.createdAt).toLocaleDateString("fr-FR", { day: "numeric", month: "short", year: "numeric" })}</time></div><p>{comment.body}</p>{(reader?.id === comment.userId || reader?.isOwner) && <button className="comment-delete" onClick={() => setDeleting(comment.id)}><Trash2 size={10}/> Supprimer</button>}</div></article>) : <p className="no-comments">Pas encore de commentaire. Et si vous ouvriez la conversation ?</p>}</div>
    {deleting && <Dialog title="Supprimer le commentaire" onClose={closeDelete}><div className="confirm-dialog"><MessageCircle size={30} strokeWidth={1.3}/><h2>Supprimer ce commentaire ?</h2><p>Il ne sera plus visible sur la publication. Cette action est définitive.</p><div className="confirm-actions"><button className="btn btn-outline" onClick={closeDelete}>Le conserver</button><button className="btn btn-danger" disabled={pending} onClick={() => startTransition(async () => { const result = await deleteComment(deleting); if (result.success) { closeDelete(); router.refresh(); notify("Le commentaire a été supprimé."); } else notify(result.error); })}>{pending ? <Loader2 size={14} className="spin"/> : <Trash2 size={14}/>} Supprimer</button></div></div></Dialog>}
  </section>;
}
