"use client";

import { createContext, useCallback, useContext, useEffect, useRef, useState, useTransition, type ReactNode } from "react";
import { usePathname } from "next/navigation";
import { ArrowRight, Check, CheckCircle2, LockKeyhole, Loader2, MessageCircle, Sparkles } from "lucide-react";
import { signInDemo } from "@/app/actions";
import type { Reader } from "@/lib/types";
import { Brand, GoogleIcon } from "@/components/brand";
import { Dialog } from "@/components/dialog";

type SiteContextValue = { reader: Reader | null; googleAvailable: boolean; openLogin: (reason?: string) => void; notify: (message: string) => void };
const SiteContext = createContext<SiteContextValue>({ reader: null, googleAvailable: false, openLogin: () => {}, notify: () => {} });
export const useSite = () => useContext(SiteContext);

export function SiteProvider({ reader, googleAvailable, allowDemo, children }: { reader: Reader | null; googleAvailable: boolean; allowDemo: boolean; children: ReactNode }) {
  const [login, setLogin] = useState(false);
  const [reason, setReason] = useState("");
  const [toast, setToast] = useState("");
  const timeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const openLogin = useCallback((message = "") => { setReason(message); setLogin(true); }, []);
  const closeLogin = useCallback(() => setLogin(false), []);
  const notify = useCallback((message: string) => { setToast(message); if (timeout.current) clearTimeout(timeout.current); timeout.current = setTimeout(() => setToast(""), 4500); }, []);
  useEffect(() => {
    const url = new URL(window.location.href);
    const status = url.searchParams.get("auth");
    if (status) {
      openLogin(status === "unavailable" ? "La connexion Google n’est pas encore configurée. Le mode découverte vous permet de tester les fonctionnalités." : "La connexion n’a pas abouti. Vous pouvez réessayer en toute sécurité.");
      url.searchParams.delete("auth"); window.history.replaceState({}, "", url.pathname + url.search + url.hash);
    }
    return () => { if (timeout.current) clearTimeout(timeout.current); };
  }, [openLogin]);
  return <SiteContext.Provider value={{ reader, googleAvailable, openLogin, notify }}>{children}{login && <LoginDialog googleAvailable={googleAvailable} allowDemo={allowDemo} reason={reason} onClose={closeLogin}/>}<div className={`toast ${toast ? "toast-visible" : ""}`} role="status" aria-live="polite"><CheckCircle2 size={19}/><span>{toast}</span></div></SiteContext.Provider>;
}
function LoginDialog({ googleAvailable, allowDemo, reason, onClose }: { googleAvailable: boolean; allowDemo: boolean; reason: string; onClose: () => void }) {
  const pathname = usePathname();
  const [demo, setDemo] = useState(false);
  const [notice, setNotice] = useState("");
  const [name, setName] = useState("");
  const [pending, startTransition] = useTransition();
  return <Dialog title="Se connecter à CephMed" onClose={onClose}><div className="login-dialog"><div className="login-brand"><Brand compact/></div><span className="eyebrow">LES ESPRITS CURIEUX SONT LES BIENVENUS</span><h2>Apprenons les uns<br/>avec les autres.</h2><p>{reason || "Connectez-vous pour partager votre avis, retrouver vos lectures et participer aux quiz."}</p><div className="login-benefits"><span><MessageCircle size={15}/> Des échanges authentiques</span><span><Sparkles size={15}/> Des découvertes à partager</span></div>{googleAvailable ? <a className="btn google-button" href={`/api/auth/google?returnTo=${encodeURIComponent(pathname)}`}><GoogleIcon/> Continuer avec Google <ArrowRight size={17}/></a> : <button className="btn google-button" onClick={() => setNotice("La connexion Google nécessite les identifiants du propriétaire. Vous pouvez utiliser le mode découverte ci-dessous, sans compte Google.")}><GoogleIcon/> Continuer avec Google <ArrowRight size={17}/></button>}<span className="login-security"><LockKeyhole size={12}/> Aucun mot de passe à créer. Votre e-mail reste privé.</span>{notice && <p className="form-notice" role="status">{notice}</p>}{allowDemo && <><div className="login-divider"><span>ou, pour découvrir le site</span></div>{!demo ? <button className="text-button demo-trigger" onClick={() => setDemo(true)}>Essayer le mode découverte <ArrowRight size={15}/></button> : <form className="demo-form" onSubmit={(e) => { e.preventDefault(); setNotice(""); startTransition(async () => { const result = await signInDemo(name); if (!result.success) setNotice(result.error || "Connexion impossible."); else { window.location.reload(); } }); }}><label htmlFor="demo-name">Comment vous appeler ?</label><input id="demo-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Votre prénom" minLength={2} maxLength={50} required autoComplete="given-name"/><button className="btn btn-primary" disabled={pending}>{pending ? <Loader2 size={17} className="spin"/> : <Check size={17}/>} Entrer en mode découverte</button><small>Compte lecteur de démonstration, distinct d’un compte Google. Vos contributions seront identifiées « Démo ».</small></form>}</>}<p className="login-legal">En continuant, vous acceptez notre <a href="/confidentialite">politique de confidentialité</a> et vous engagez à échanger avec bienveillance.</p></div></Dialog>;
}
