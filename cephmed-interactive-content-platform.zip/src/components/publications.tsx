"use client";

import Link from "next/link";
import { useEffect, useMemo, useState, useTransition } from "react";
import { ArrowRight, ArrowUpRight, Bookmark, BookOpen, Brain, Clock3, Leaf, Loader2, MessageCircle, Search, SlidersHorizontal, Sparkles, Users, X } from "lucide-react";
import { setBookmark } from "@/app/actions";
import { BookArt, QuizArt } from "@/components/brand";
import { useSite } from "@/components/site-provider";
import type { Publication } from "@/lib/types";
import type { PublicationKind } from "@/db/schema";

export const kindLabels = { conseil: "Conseil", livre: "Livre", quiz: "Quiz" };
export function BookmarkButton({ id, saved = false, className = "" }: { id: string; saved?: boolean; className?: string }) {
  const { reader, openLogin, notify } = useSite();
  const [active, setActive] = useState(saved);
  const [pending, startTransition] = useTransition();
  useEffect(() => { setActive(saved); }, [saved, reader?.id]);
  return <button className={`bookmark-button ${active ? "is-saved" : ""} ${className}`} aria-label={active ? "Retirer de mes favoris" : "Enregistrer dans mes favoris"} aria-pressed={active} disabled={pending} onClick={() => {
    if (!reader) { openLogin("Connectez-vous pour garder vos lectures préférées à portée de main."); return; }
    startTransition(async () => { const result = await setBookmark(id, !active); if (result.success) { setActive(!active); notify(active ? "Publication retirée de vos favoris." : "Publication enregistrée dans votre espace."); } else notify(result.error); });
  }}>{pending ? <Loader2 className="spin" size={17}/> : <Bookmark size={17} fill={active ? "currentColor" : "none"} strokeWidth={1.7}/>}</button>;
}
export function PublicationVisual({ post }: { post: Publication }) {
  if (post.cover) return <img src={post.cover} alt={post.kind === "conseil" ? "Un moment de calme et de bien-être au quotidien" : post.title} loading="lazy" className="publication-image"/>;
  if (post.kind === "livre") return <BookArt title={post.title} author={post.bookAuthor}/>;
  if (post.kind === "quiz") return <QuizArt count={post.questionCount}/>;
  return <div className="fallback-art"><Leaf size={62} strokeWidth={1}/><span>Prendre le temps de mieux vivre.</span></div>;
}
export function PublicationCard({ post, saved }: { post: Publication; saved?: boolean }) {
  const TypeIcon = post.kind === "conseil" ? Leaf : post.kind === "livre" ? BookOpen : Brain;
  return <article className={`publication-card card-${post.kind}`}><div className="publication-visual"><Link href={`/publications/${post.id}`} tabIndex={-1} aria-label={post.title}><PublicationVisual post={post}/></Link><span className={`type-badge type-${post.kind}`}><TypeIcon size={12}/>{kindLabels[post.kind]}</span><BookmarkButton id={post.id} saved={saved}/>{post.kind === "quiz" && <span className={`quiz-state ${post.resultsPublished ? "closed" : ""}`}><span/>{post.resultsPublished ? "Résultats disponibles" : "À vous de jouer"}</span>}</div><div className="publication-card-body"><div className="card-topic">{post.topic}</div><Link className="card-title-link" href={`/publications/${post.id}`}><h3>{post.title}</h3></Link>{post.kind === "livre" && <span className="card-author">de {post.bookAuthor}</span>}<p className="card-excerpt">{post.excerpt}</p><div className="card-footer"><span><Clock3 size={13}/>{post.kind === "quiz" ? `${post.questionCount} questions · 20 s / question` : `${post.readingTime} min de lecture`}</span><span>{post.kind === "quiz" ? <><Users size={14}/>{post.participantCount}</> : <><MessageCircle size={14}/>{post.commentCount}</>}</span><Link href={`/publications/${post.id}`} className="card-read" aria-label={`Découvrir : ${post.title}`}><ArrowUpRight size={18}/></Link></div></div></article>;
}
const filters: { key: PublicationKind | "all"; label: string; icon: typeof Leaf }[] = [{ key: "all", label: "Tout explorer", icon: Sparkles }, { key: "conseil", label: "Conseils", icon: Leaf }, { key: "livre", label: "Livres", icon: BookOpen }, { key: "quiz", label: "Quiz", icon: Brain }];
export function PublicationExplorer({ posts, savedIds = [], home = false, initialFilter = "all", initialSearch = "", showFilters = true }: { posts: Publication[]; savedIds?: string[]; home?: boolean; initialFilter?: PublicationKind | "all"; initialSearch?: string; showFilters?: boolean }) {
  const [filter, setFilter] = useState<PublicationKind | "all">(initialFilter);
  const [search, setSearch] = useState(initialSearch);
  const normalize = (str: string) => str.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
  const filtered = useMemo(() => posts.filter((p) => (filter === "all" || p.kind === filter) && normalize(`${p.title} ${p.excerpt} ${p.topic} ${p.bookAuthor ?? ""}`).includes(normalize(search))), [posts, filter, search]);
  const visible = home && !search && filter === "all" ? filtered.slice(0, 3) : filtered;
  return <section id="publications" className={`publication-section ${home ? "home-publications" : ""}`}>
    {home && <div className="section-heading"><div><span className="eyebrow">À LIRE, À DÉCOUVRIR, À PARTAGER</span><h2>Votre prochaine découverte</h2></div><Link className="text-link" href="/publications">Toutes les publications <ArrowUpRight size={17}/></Link></div>}
    <div className="browse-toolbar">{showFilters ? <div className="filter-tabs" aria-label="Filtrer les publications">{filters.map((item) => <button className={`filter-tab ${filter === item.key ? "selected" : ""}`} key={item.key} onClick={() => setFilter(item.key)} aria-pressed={filter === item.key}><item.icon size={15} strokeWidth={1.6}/>{item.label}</button>)}</div> : <span className="result-count"><SlidersHorizontal size={16}/>{filtered.length} {filtered.length > 1 ? "publications à découvrir" : "publication à découvrir"}</span>}<div className="inline-search"><Search size={16}/><input aria-label="Rechercher parmi les publications" placeholder="Un sujet vous intéresse ?" value={search} onChange={(e) => setSearch(e.target.value)}/>{search && <button aria-label="Effacer la recherche" onClick={() => setSearch("")}><X size={14}/></button>}</div></div>
    {visible.length ? <div className="publication-grid">{visible.map((post) => <PublicationCard key={post.id} post={post} saved={savedIds.includes(post.id)}/>)}</div> : <div className="empty-state"><Search size={32} strokeWidth={1.3}/><h3>La curiosité continue ailleurs.</h3><p>Aucune publication ne correspond à votre recherche. Essayez un autre mot ou une autre catégorie.</p><button className="btn btn-outline" onClick={() => { setSearch(""); setFilter(initialFilter); }}>Réinitialiser la recherche <ArrowRight size={15}/></button></div>}
  </section>;
}
