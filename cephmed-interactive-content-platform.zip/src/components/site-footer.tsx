import Link from "next/link";
import { Heart } from "lucide-react";
import { Brand } from "@/components/brand";

export function SiteFooter() {
  return <footer className="site-footer"><div className="container"><div className="footer-main"><div className="footer-brand"><Link href="/" aria-label="CephMed — Accueil"><Brand/></Link><p>Un peu de savoir. Beaucoup de sens.<br/>Un espace pour apprendre et grandir, ensemble.</p></div><div className="footer-column"><h3>À explorer</h3><Link href="/conseils">Les conseils</Link><Link href="/bibliotheque">La bibliothèque</Link><Link href="/quiz">Les quiz</Link></div><div className="footer-column"><h3>Restons curieux</h3><Link href="/a-propos">À propos de CephMed</Link><Link href="/mon-espace">Mon espace lecteur</Link></div></div><div className="footer-bottom"><span>© {new Date().getFullYear()} CephMed. Tous droits réservés.</span><span className="made-with">Cultivé avec soin <Heart size={12}/></span><Link href="/confidentialite">Confidentialité & mentions légales</Link></div></div></footer>;
}
