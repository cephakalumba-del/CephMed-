"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ArrowRight, Brain, Check, CheckCircle2, Clock3, ListChecks, Loader2, LockKeyhole, RefreshCw, ShieldCheck, Timer, Trophy, WifiOff } from "lucide-react";
import { useSite } from "@/components/site-provider";
import { formatQuizTime, QUESTION_TIME_MS } from "@/lib/quiz-rules";
import type { Attempt, Publication, QuizSnapshot, Result } from "@/lib/types";

type AnswerRequest = { action: "answer"; questionIndex: number; questionToken: string; answer: number | null };
type RequestBody = { action: "start" } | AnswerRequest;

export function QuizPlayer({ post, attempt, results }: { post: Publication; attempt: Attempt | null; results: Result[] }) {
  const { reader, openLogin } = useSite();
  const router = useRouter();
  const [state, setState] = useState<QuizSnapshot | null>(null);
  const stateRef = useRef<QuizSnapshot | null>(null);
  const [loading, setLoading] = useState(Boolean(reader && !reader.isOwner));
  const [busy, setBusy] = useState(false);
  const busyRef = useRef(false);
  const [error, setError] = useState("");
  const [authExpired, setAuthExpired] = useState(false);
  const [remaining, setRemaining] = useState(QUESTION_TIME_MS);
  const clock = useRef({ receivedAt: 0, remainingAtReceipt: QUESTION_TIME_MS });
  const retryPayload = useRef<RequestBody | undefined>(undefined);
  const nextRetry = useRef(0);
  const heading = useRef<HTMLHeadingElement>(null);
  const panel = useRef<HTMLElement>(null);

  const sync = useCallback(async (payload?: RequestBody) => {
    if (busyRef.current || !reader || reader.isOwner) return;
    busyRef.current = true;
    setBusy(true);
    setError("");
    const sentAt = performance.now();
    try {
      const response = await fetch(`/api/quiz/${encodeURIComponent(post.id)}`, {
        method: payload ? "POST" : "GET", cache: "no-store", credentials: "same-origin",
        headers: payload ? { "Content-Type": "application/json" } : undefined,
        body: payload ? JSON.stringify(payload) : undefined, signal: AbortSignal.timeout(10_000),
      });
      const data = await response.json();
      if (!response.ok) {
        if (response.status === 401) setAuthExpired(true);
        throw new Error(data.error || "La connexion a été interrompue.");
      }
      const next = data as QuizSnapshot;
      retryPayload.current = undefined;
      setAuthExpired(false);
      // An old tab/request must never put the UI on a previous question.
      if (stateRef.current?.status === "completed" && next.status !== "completed") return;
      if (stateRef.current && next.status === "in_progress" && next.index < stateRef.current.index) return;
      const previous = stateRef.current;
      stateRef.current = next;
      clock.current = { receivedAt: performance.now(), remainingAtReceipt: Math.max(0, (next.deadlineMs ?? next.serverNowMs) - next.serverNowMs - (performance.now() - sentAt) / 2) };
      setRemaining(clock.current.remainingAtReceipt);
      setState(next);
      if (next.status === "completed" && previous?.status === "in_progress") router.refresh();
      if (payload?.action === "start") panel.current?.scrollIntoView({ behavior: "smooth", block: "center" });
    } catch (caught) {
      retryPayload.current = payload;
      setError(caught instanceof Error && caught.name !== "TimeoutError" ? caught.message : "La connexion a été interrompue. Le chronomètre serveur continue.");
    } finally { busyRef.current = false; setBusy(false); setLoading(false); }
  }, [post.id, reader, router]);

  useEffect(() => { if (reader && !reader.isOwner && !post.resultsPublished) void sync(); else setLoading(false); }, [reader, post.resultsPublished, sync]);
  useEffect(() => {
    if (state?.status !== "in_progress") return;
    const tick = () => {
      const left = Math.max(0, clock.current.remainingAtReceipt - (performance.now() - clock.current.receivedAt));
      setRemaining(left);
      if (!left && !busyRef.current && performance.now() >= nextRetry.current && !authExpired) {
        nextRetry.current = performance.now() + 1200;
        const current = stateRef.current;
        if (current?.questionToken && current.status === "in_progress") void sync(retryPayload.current ?? { action: "answer", questionIndex: current.index, questionToken: current.questionToken, answer: null });
      }
    };
    tick();
    const timer = setInterval(tick, 100);
    return () => clearInterval(timer);
  }, [state, sync, authExpired]);
  useEffect(() => {
    const recover = () => { if (stateRef.current?.status === "in_progress" && document.visibilityState === "visible") void sync(retryPayload.current); };
    window.addEventListener("online", recover);
    document.addEventListener("visibilitychange", recover);
    // Synchronize concurrent tabs without pausing or restarting a question.
    const interval = setInterval(recover, 5000);
    return () => { window.removeEventListener("online", recover); document.removeEventListener("visibilitychange", recover); clearInterval(interval); };
  }, [sync]);
  useEffect(() => { if (state?.status === "in_progress") heading.current?.focus({ preventScroll: true }); }, [state?.index, state?.status]);

  if (reader?.isOwner) return <section className="quiz-panel quiz-waiting"><div className="waiting-icon"><ShieldCheck size={30} strokeWidth={1.4}/></div><span className="eyebrow">RÉSERVÉ À VOTRE REGARD</span><h2>La correction se passe<br/>dans votre studio.</h2><p>Les réponses sont corrigées et chronométrées automatiquement. Consultez votre classement privé et le détail de chaque participation.</p><Link className="btn btn-primary" href="/studio" style={{ marginTop: 22 }}>Ouvrir mon studio <ArrowRight size={15}/></Link></section>;

  if (post.resultsPublished) return <section className="quiz-panel"><div className="quiz-score"><div className="waiting-icon"><Trophy size={29} strokeWidth={1.4}/></div><span className="eyebrow">CLASSEMENT PUBLIÉ PAR CEPHMED</span><h2>Les résultats sont là !</h2><p>Le quiz est clôturé. Les corrections détaillées restent privées.</p></div><div className="leaderboard"><h3>Les esprits curieux du quiz</h3><p className="ranking-rule">Bonnes réponses décroissantes, puis temps cumulé sur les bonnes réponses croissant. Égalités exactes : ex æquo.</p>{results.length ? results.map((result) => <div className="ranking-row" key={`${result.name}-${result.createdAt}`}><span className="ranking-rank">{result.rank === 1 ? <Trophy size={15}/> : String(result.rank).padStart(2, "0")}</span><span>{result.name}</span><span className="ranking-time">{formatQuizTime(result.correctTimeMs)}</span><strong>{result.score} / {post.questionCount}</strong></div>) : <p className="ranking-empty">Aucune participation chronométrée hors démonstration dans ce classement.</p>}</div><Link href="/quiz" className="text-link" style={{ marginTop: 25, fontSize: 11 }}>Découvrir les autres quiz <ArrowRight size={15}/></Link></section>;

  if (state?.status === "completed" || (!state && attempt?.status === "completed")) return <section className="quiz-panel quiz-waiting"><div className="waiting-icon"><CheckCircle2 size={30} strokeWidth={1.4}/></div><span className="eyebrow">MERCI D’AVOIR JOUÉ LE JEU</span><h2>Votre participation<br/>est bien enregistrée.</h2><p>Vos réponses ont été corrigées automatiquement. Les scores, les temps et les corrections sont réservés au propriétaire, qui décidera de publier le classement final.</p><div className="waiting-status"><LockKeyhole size={15}/> En attente de la publication du classement</div><Link href="/mon-espace" className="text-link" style={{ marginTop: 23, fontSize: 11 }}>Retrouver mes participations <ArrowRight size={15}/></Link></section>;

  const errorNotice = error && <div className="quiz-connection-error" role="alert"><WifiOff size={16}/><div><p>{error}</p><button type="button" className="text-button" disabled={busy} onClick={() => authExpired ? openLogin("Reconnectez-vous pour reprendre votre quiz. Le chronomètre ne s’est pas arrêté.") : void sync(retryPayload.current)}>{authExpired ? "Me reconnecter" : "Réessayer la synchronisation"}<RefreshCw size={12}/></button></div></div>;
  if (state?.status === "closed") return <section className="quiz-panel quiz-waiting"><div className="waiting-icon"><LockKeyhole size={27}/></div><h2>Ce quiz est clôturé.</h2><p>Le propriétaire a publié son classement.</p><button className="btn btn-outline" onClick={() => window.location.reload()} style={{ marginTop: 20 }}>Afficher le classement <ArrowRight size={14}/></button></section>;
  if (!state || state.status === "ready") return <section className="quiz-panel" ref={panel}><div className="quiz-intro"><div className="quiz-intro-icon"><Timer size={32} strokeWidth={1.3}/></div><span className="eyebrow">UN PEU DE RÉFLEXION. UN PEU DE RAPIDITÉ.</span><h2>20 secondes, à vous de jouer.</h2><p>Une question à la fois, dans l’ordre.<br/>Un clic valide votre réponse et ouvre la suivante.</p><div className="quiz-facts"><span><ListChecks size={15}/>{post.questionCount} questions</span><span><Clock3 size={15}/>20 s par question</span></div><div className="timed-quiz-rules"><span><Check size={14}/>Une réponse donnée est définitive.</span><span><Timer size={14}/>À 20 secondes, la question passe automatiquement.</span><span><LockKeyhole size={14}/>Aucun retour, aucune pause, même après rechargement.</span></div><button className="btn btn-primary" disabled={busy || loading || !post.questionCount} onClick={() => reader ? void sync({ action: "start" }) : openLogin("Connectez-vous pour participer au quiz chronométré. Vous disposerez de 20 secondes par question.")}>{busy || loading ? <><Loader2 size={16} className="spin"/> Synchronisation…</> : <>{reader ? "Commencer le quiz" : "Me connecter et participer"}<ArrowRight size={16}/></>}</button><small>Le nombre de bonnes réponses prime. À égalité, le temps cumulé sur les bonnes réponses vous départage.</small><small>En commençant, vous acceptez la publication éventuelle de votre nom, score et temps de départage. Les corrections restent privées.{reader?.isDemo ? " Votre participation de démonstration sera hors classement officiel." : ""}</small><small>Le temps est mesuré côté serveur, réception réseau incluse. Préparez-vous avant de commencer.</small></div>{errorNotice}</section>;

  const seconds = Math.ceil(remaining / 1000);
  const current = state.question;
  return <section ref={panel} className={`quiz-panel timed-quiz-panel ${seconds <= 5 ? "time-running-low" : ""}`} aria-label="Quiz chronométré" data-question-index={state.index}>
    <div className="timed-quiz-top"><div><span className="eyebrow">CHAQUE SECONDE COMPTE</span><div className="timed-question-count">Question <strong>{state.index + 1}</strong> sur {state.total}</div></div><div className="timed-clock" role="timer" aria-label={`${seconds} secondes restantes`} aria-live="off"><svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="32" r="28" className="clock-track"/><circle cx="32" cy="32" r="28" className="clock-remaining" strokeDasharray={176} strokeDashoffset={176 * (1 - remaining / QUESTION_TIME_MS)}/></svg><strong>{seconds}<small>SEC</small></strong></div></div>
    <div className="quiz-progress" role="progressbar" aria-label="Questions terminées" aria-valuemin={0} aria-valuemax={state.total} aria-valuenow={state.index}><span style={{ width: `${state.index / state.total * 100}%` }}/></div>
    <h2 className="quiz-question" ref={heading} tabIndex={-1} id="timed-question">{current?.question}</h2>
    <div className="quiz-options" role="group" aria-labelledby="timed-question">{current?.options.map((option, i) => <button type="button" className="quiz-option" disabled={busy || remaining <= 0 || authExpired} key={`${state.index}-${i}`} onClick={() => { if (state.questionToken) void sync({ action: "answer", questionIndex: state.index, questionToken: state.questionToken, answer: i }); }}><span className="option-letter">{String.fromCharCode(65 + i)}</span><span>{option}</span><ArrowRight size={14}/></button>)}</div>
    <div className="timed-status" role="status">{busy ? <><Loader2 size={14} className="spin"/> Enregistrement et passage à la suite…</> : remaining <= 0 ? <><Timer size={14}/> Temps écoulé. Passage à la question suivante…</> : <><LockKeyhole size={13}/> Cliquez pour répondre. Votre choix est définitif.</>}</div>{state.notice && <p className="timed-sync-note">{state.notice}</p>}{errorNotice}
    <div className="timed-question-dots" aria-hidden="true">{Array.from({ length: state.total }, (_, i) => <span key={i} className={i < state.index ? "finished" : i === state.index ? "current" : ""}>{i < state.index ? <Check size={10}/> : i + 1}</span>)}</div>
  </section>;
}
