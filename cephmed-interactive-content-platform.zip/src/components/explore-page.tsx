import Link from "next/link";
import { ArrowRight, BookOpen, Brain, ChevronRight, Leaf, LockKeyhole, Sparkles } from "lucide-react";
import { getReader } from "@/lib/auth";
import { getPublications, getSavedIds } from "@/lib/content";
import { PublicationExplorer } from "@/components/publications";
import type { PublicationKind } from "@/db/schema";

const descriptions = {
  all: { title: "Suivez votre curiosité.", eyebrow: "TOUT L’UNIVERS CEPHMED", text: "Une idée qui fait du bien, un livre qui ouvre une porte, une question qui fait réfléchir. Choisissez votre prochaine découverte.", icon: Sparkles, label: "Les publications" },
  conseil: { title: "Mieux vivre, simplement.", eyebrow: "LES CONSEILS CEPHMED", text: "Des repères concrets et un regard attentif sur le quotidien. Pas de recette miracle : des pistes à explorer, à votre rythme.", icon: Leaf, label: "Conseils" },
  livre: { title: "Des livres, des horizons.", eyebrow: "LA BIBLIOTHÈQUE CEPHMED", text: "Des lectures choisies avec soin, des idées qui restent. Je partage ici mes recommandations et ce que chaque livre m’a apporté.", icon: BookOpen, label: "Bibliothèque" },
  quiz: { title: "À vous de jouer.", eyebrow: "LES QUIZ CEPHMED", text: "Apprendre commence souvent par une bonne question. Testez vos connaissances, bousculez les idées reçues et cultivez le plaisir de découvrir.", icon: Brain, label: "Quiz" },
};
export async function ExplorePage({ kind = "all", search = "" }: { kind?: PublicationKind | "all"; search?: string }) {
  const reader = await getReader();
  const [posts, savedIds] = await Promise.all([getPublications(), getSavedIds(reader)]);
  const data = descriptions[kind];
  return <main className="page-main"><div className="container"><div className="page-intro"><div className="breadcrumb"><Link href="/">Accueil</Link><ChevronRight size={12}/><span>{data.label}</span></div><span className="eyebrow">{data.eyebrow}</span><div className="page-intro-heading"><h1>{data.title}</h1><span className="page-intro-icon"><data.icon size={27} strokeWidth={1.3}/></span></div><p>{data.text}</p>{kind === "quiz" && <div className="collection-note"><LockKeyhole size={13}/> 20 secondes par question, sans retour. Classement publié uniquement par CephMed.</div>}{kind === "livre" && <div className="collection-note"><BookOpen size={13}/> Des recommandations personnelles, sans lien d’affiliation.</div>}</div><PublicationExplorer key={`${kind}-${search}`} posts={posts} savedIds={savedIds} initialFilter={kind} initialSearch={search} showFilters={kind === "all"}/><div className="reading-end"><Sparkles size={15}/><span>La curiosité n’a pas de fin.</span><Link href="/a-propos" className="text-link" style={{ marginLeft: "auto", fontSize: 10 }}>L’esprit CephMed <ArrowRight size={14}/></Link></div></div></main>;
}
