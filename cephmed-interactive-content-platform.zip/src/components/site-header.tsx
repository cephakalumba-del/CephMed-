"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState, useTransition } from "react";
import { ArrowRight, Bookmark, ChevronDown, LayoutDashboard, Loader2, LogOut, Menu, Search, X } from "lucide-react";
import { Brand, GoogleIcon } from "@/components/brand";
import { useSite } from "@/components/site-provider";
import { Dialog } from "@/components/dialog";
import { signOut } from "@/app/actions";

const links = [{ label: "Accueil", href: "/" }, { label: "Conseils", href: "/conseils" }, { label: "Bibliothèque", href: "/bibliotheque" }, { label: "Quiz", href: "/quiz" }, { label: "À propos", href: "/a-propos" }];
export function SiteHeader() {
  const { reader, openLogin } = useSite();
  const pathname = usePathname();
  const router = useRouter();
  const [menu, setMenu] = useState(false);
  const [account, setAccount] = useState(false);
  const [search, setSearch] = useState(false);
  const [query, setQuery] = useState("");
  const [pending, startTransition] = useTransition();
  const accountRef = useRef<HTMLDivElement>(null);
  const closeSearch = useCallback(() => setSearch(false), []);
  useEffect(() => {
    const close = (e: MouseEvent) => { if (!accountRef.current?.contains(e.target as Node)) setAccount(false); };
    document.addEventListener("click", close);
    return () => document.removeEventListener("click", close);
  }, []);
  return <>
    <header className="site-header"><div className="container header-inner">
      <Link href="/" className="logo-link" aria-label="CephMed — Accueil"><Brand/></Link>
      <nav className="desktop-nav" aria-label="Navigation principale">{links.map((link) => <Link key={link.href} href={link.href} className={`nav-link ${pathname === link.href ? "active" : ""}`} aria-current={pathname === link.href ? "page" : undefined}>{link.label}</Link>)}</nav>
      <div className="header-actions"><button className="icon-button header-search" aria-label="Rechercher une publication" onClick={() => setSearch(true)}><Search size={20} strokeWidth={1.6}/></button><span className="header-separator"/>
        {reader ? <div className="account-wrapper" ref={accountRef}><button className="account-button" onClick={() => setAccount(!account)} aria-expanded={account}><span className="avatar">{reader.avatar ? <img src={reader.avatar} alt="" referrerPolicy="no-referrer"/> : reader.name.charAt(0).toUpperCase()}</span><span className="account-name">{reader.name.split(" ")[0]}</span><ChevronDown size={14}/></button>{account && <div className="account-menu"><div className="account-menu-heading"><strong>{reader.name}</strong><small>{reader.isDemo ? "Compte de découverte" : reader.isOwner ? "Propriétaire de CephMed" : "Membre de CephMed"}</small></div><Link href="/mon-espace" onClick={() => setAccount(false)}><Bookmark size={16}/> Mon espace</Link>{reader.isOwner && <Link href="/studio" onClick={() => setAccount(false)}><LayoutDashboard size={16}/> Mon studio</Link>}<button disabled={pending} onClick={() => startTransition(async () => { await signOut(); window.location.assign("/"); })}>{pending ? <Loader2 className="spin" size={16}/> : <LogOut size={16}/>} Se déconnecter</button></div>}</div> : <button className="btn login-button" onClick={() => openLogin()}><GoogleIcon/><span>Se connecter</span></button>}
        <button className="icon-button mobile-menu-toggle" onClick={() => setMenu(!menu)} aria-label={menu ? "Fermer le menu" : "Ouvrir le menu"} aria-expanded={menu}>{menu ? <X size={23}/> : <Menu size={23}/>}</button>
      </div>
    </div>{menu && <nav className="mobile-nav" aria-label="Navigation mobile">{links.map((link) => <Link key={link.href} href={link.href} onClick={() => setMenu(false)} className={pathname === link.href ? "active" : ""}>{link.label}<ArrowRight size={15}/></Link>)}</nav>}</header>
    {search && <Dialog title="Rechercher sur CephMed" onClose={closeSearch}><div className="search-dialog"><span className="eyebrow">SUIVEZ VOTRE CURIOSITÉ</span><h2>Que souhaitez-vous découvrir ?</h2><form onSubmit={(e) => { e.preventDefault(); closeSearch(); router.push(`/publications?recherche=${encodeURIComponent(query.trim())}`); }}><div className="search-field"><Search size={19}/><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Un sujet, un livre, une envie…" autoFocus aria-label="Votre recherche"/></div><button className="btn btn-primary" type="submit">Rechercher <ArrowRight size={16}/></button></form><p>Quelques pistes pour commencer</p><div className="suggested-searches">{["Sommeil", "Habitudes", "Cerveau", "Simplicité"].map((word) => <button key={word} onClick={() => { closeSearch(); router.push(`/publications?recherche=${encodeURIComponent(word)}`); }}>{word}<ArrowRight size={13}/></button>)}</div></div></Dialog>}
  </>;
}
